import { o as __toESM } from "../_runtime.mjs";
import { r as require_react, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { t as require_jsx_dev_runtime } from "../_libs/react.mjs";
import { c as HeadContent, d as Outlet, f as lazyRouteComponent, g as useRouter, h as Link, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Crx5VXq4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_dev_runtime = require_jsx_dev_runtime();
var styles_default = "/assets/styles-BzCFndUn.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
var _jsxFileName = "E:/2. Job Search [USA🗽]/5. ⭐Wynisco⭐/4. Onboarding/3. Technical Prep/z. Projects/Multi AI Agents with Langgraph/multi-agent-job-assistant/src/routes/__root.tsx";
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "font-mono text-xs uppercase tracking-[0.3em] text-accent",
					children: "Error 404"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h1", {
					className: "mt-4 text-4xl font-bold text-foreground",
					children: "NODE_NOT_FOUND"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: "This route is not registered in the graph topology."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
					to: "/",
					className: "mt-6 inline-flex items-center justify-center rounded-md bg-accent px-5 py-2 font-mono text-xs font-bold uppercase tracking-wider text-accent-foreground transition-colors hover:bg-accent/90",
					children: "Return to console"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "font-mono text-xs uppercase tracking-[0.3em] text-destructive",
					children: "Runtime Fault"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h1", {
					className: "mt-4 text-2xl font-bold text-foreground",
					children: "Kernel panic in agent graph"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The orchestrator crashed. Restart the session or return home."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-accent px-5 py-2 font-mono text-xs font-bold uppercase tracking-wider text-accent-foreground hover:bg-accent/90",
						children: "Retry"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-border bg-transparent px-5 py-2 font-mono text-xs font-bold uppercase tracking-wider text-foreground hover:bg-secondary",
						children: "Home"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 47,
		columnNumber: 5
	}, this);
}
var Route$4 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Agentic.OS — Multi-Agent Job Application Assistant" },
			{
				name: "description",
				content: "A LangGraph-inspired multi-agent system that researches companies, matches your resume against the JD, and generates tailored interview prep — live, in your browser."
			},
			{
				name: "author",
				content: "Agentic.OS"
			},
			{
				property: "og:title",
				content: "Agentic.OS — Multi-Agent Job Application Assistant"
			},
			{
				property: "og:description",
				content: "Watch a Supervisor route Research, Matcher, and Prep agents in real time — compiled into a recruiter-ready case file."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("html", {
		lang: "en",
		className: "dark",
		children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("head", { children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(HeadContent, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 129,
			columnNumber: 9
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 128,
			columnNumber: 7
		}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Scripts, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 133,
			columnNumber: 9
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 131,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 127,
		columnNumber: 5
	}, this);
}
function RootComponent() {
	const { queryClient } = Route$4.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Outlet, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 144,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 143,
		columnNumber: 5
	}, this);
}
var $$splitComponentImporter$2 = () => import("./index_temp-D6lqw0Gx.mjs");
var Route$3 = createFileRoute("/index_temp")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./index-backup-EzlGQO2R.mjs");
var Route$2 = createFileRoute("/index-backup")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./routes-D2hLxTs-.mjs");
var Route$1 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var MODEL = "google/gemini-2.5-flash";
function getProviderConfig() {
	const provider = (processModule.env.AI_PROVIDER || "lovable").toLowerCase();
	if (provider === "openrouter") return {
		url: "https://api.openrouter.ai/v1/chat/completions",
		key: processModule.env.OPENROUTER_API_KEY,
		name: "openrouter"
	};
	if (provider === "gemini") return {
		url: processModule.env.AI_GATEWAY_URL || "https://api.openai.com/v1/chat/completions",
		key: processModule.env.GEMINI_API_KEY,
		name: "gemini"
	};
	return {
		url: processModule.env.AI_GATEWAY_URL || "https://ai.gateway.lovable.dev/v1/chat/completions",
		key: processModule.env.LOVABLE_API_KEY,
		name: "lovable"
	};
}
var AGENTS = [
	{
		id: "supervisor",
		label: "Supervisor",
		system: "You are the SUPERVISOR node of a multi-agent job-application system. Your job is to briefly analyze a Job Description and the candidate's Resume, then dispatch work to three specialists: RESEARCHER (company/market intel), MATCHER (resume-vs-JD gap analysis), PREP (interview prep). Respond in 4-6 short bullet points in the format:\n• Candidate: <name + key strengths from resume>\n• Role: <extracted title from JD>\n• Company/Stack: <key tech from JD>\n• Dispatch → RESEARCHER: <one-line brief>\n• Dispatch → MATCHER: <one-line brief>\n• Dispatch → PREP: <one-line brief>\nNo preamble. Be terse. Use plain text.",
		buildUser: ({ jd, resume }) => `CANDIDATE RESUME:\n"""\n${resume}\n"""\n\nJOB DESCRIPTION:\n"""\n${jd}\n"""`
	},
	{
		id: "researcher",
		label: "Researcher",
		system: "You are the RESEARCHER agent. Given a JD and candidate resume, produce concise intelligence the candidate needs BEFORE interviewing. Focus on company intel that complements their background. Return markdown with sections: **Company Snapshot**, **Tech & Stack Signals**, **Market/Competitive Context**, **Culture Cues**. 3-6 bullets per section. Ground claims in what the JD implies; if unknown, say so. Be crisp, no fluff.",
		buildUser: ({ jd, resume, prior }) => `SUPERVISOR BRIEF:\n${prior.supervisor}\n\nCANDIDATE RESUME:\n"""\n${resume}\n"""\n\nJOB DESCRIPTION:\n"""\n${jd}\n"""`
	},
	{
		id: "matcher",
		label: "Matcher",
		system: "You are the MATCHER agent. Perform a detailed gap analysis between the candidate's actual resume and the JD requirements. Analyze their specific experience, skills, projects, and background against what's needed. Return markdown with: **Match Score: XX%** on the first line, then **Strong Matches** (specific skills/experience from their resume), **Partial Matches** (transferable skills), **Gaps** (missing requirements), **Recommendation** (1 tailored paragraph for this specific candidate). Score realistically 55–95 based on their actual background. No generic advice - be specific to their profile.",
		buildUser: ({ jd, resume, prior }) => `RESEARCH CONTEXT:\n${prior.researcher}\n\nCANDIDATE RESUME:\n"""\n${resume}\n"""\n\nJOB DESCRIPTION:\n"""\n${jd}\n"""`
	},
	{
		id: "prep",
		label: "Prep Agent",
		system: "You are the PREP agent. Using the JD, research context, gap analysis, and the candidate's specific background, produce a highly personalized interview prep sheet. Leverage their actual projects, experience, and skills to craft targeted responses. Return markdown with: **Likely Technical Questions** (5 questions they should expect based on the role + their background), **Behavioral Prompts** (3 questions where they can showcase their specific experience), **Questions to Ask Them** (3 strategic questions based on their level and the company), **48-Hour Study Plan** (3 personalized bullets based on their gaps and strengths). Reference their actual projects, experience, and skills throughout. Be specific, not generic.",
		buildUser: ({ jd, resume, prior }) => `RESEARCH:\n${prior.researcher}\n\nMATCH ANALYSIS:\n${prior.matcher}\n\nCANDIDATE RESUME:\n"""\n${resume}\n"""\n\nJOB DESCRIPTION:\n"""\n${jd}\n"""`
	}
];
function sseEvent(obj) {
	return `data: ${JSON.stringify(obj)}\n\n`;
}
var Route = createFileRoute("/api/analyze")({ server: { handlers: { POST: async ({ request }) => {
	const cfg = getProviderConfig();
	const apiKey = cfg.key;
	if (!apiKey) return new Response(`Missing API key for provider ${cfg.name} on server`, { status: 500 });
	let jd = "";
	let resume = "";
	try {
		const body = await request.json();
		jd = (body.jd ?? "").trim();
		resume = (body.resume ?? "").trim();
	} catch {
		return new Response("Invalid JSON body", { status: 400 });
	}
	if (jd.length < 20) return new Response("Job description too short", { status: 400 });
	if (resume.length < 50) return new Response("Resume too short for analysis", { status: 400 });
	if (jd.length > 8e3) jd = jd.slice(0, 8e3);
	if (resume.length > 12e3) resume = resume.slice(0, 12e3);
	const encoder = new TextEncoder();
	const stream = new ReadableStream({ async start(controller) {
		const send = (obj) => controller.enqueue(encoder.encode(sseEvent(obj)));
		const prior = {};
		try {
			send({
				type: "start",
				ts: Date.now()
			});
			for (const agent of AGENTS) {
				send({
					type: "agent_start",
					agent: agent.id,
					label: agent.label
				});
				if (cfg.name === "gemini") {
					const prompt = `${agent.system}\n\n${agent.buildUser({
						jd,
						resume,
						prior
					})}`;
					const modelShort = MODEL.replace("google/", "");
					const geminiUrl = processModule.env.GEMINI_API_URL || `https://generativelanguage.googleapis.com/v1/models/${modelShort}:generateContent?key=${apiKey}`;
					let parsedText = "";
					try {
						const gemRes = await fetch(geminiUrl, {
							method: "POST",
							headers: { "Content-Type": "application/json" },
							body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
						});
						if (!gemRes.ok) {
							const t = await gemRes.text().catch(() => "");
							send({
								type: "error",
								agent: agent.id,
								message: `Gateway error ${gemRes.status}: ${t.slice(0, 200)}`
							});
							break;
						}
						const data = await gemRes.json().catch(() => ({}));
						parsedText = data.candidates?.[0]?.content?.parts?.map((p) => p.text).join("") || data.candidates?.[0]?.content || data.candidates?.[0]?.output?.[0]?.content || data.output?.text || data.choices?.[0]?.message?.content || data.choices?.[0]?.text || "";
					} catch (err) {
						send({
							type: "error",
							agent: agent.id,
							message: err instanceof Error ? err.message : String(err)
						});
						break;
					}
					prior[agent.id] = parsedText;
					send({
						type: "token",
						agent: agent.id,
						delta: parsedText
					});
					send({
						type: "agent_done",
						agent: agent.id,
						content: parsedText
					});
					continue;
				}
				const res = await fetch(cfg.url, {
					method: "POST",
					headers: {
						"Content-Type": "application/json",
						Authorization: `Bearer ${apiKey}`
					},
					body: JSON.stringify({
						model: MODEL,
						stream: true,
						messages: [{
							role: "system",
							content: agent.system
						}, {
							role: "user",
							content: agent.buildUser({
								jd,
								resume,
								prior
							})
						}]
					})
				});
				if (res.status === 429) {
					send({
						type: "error",
						agent: agent.id,
						message: "Rate limited by AI gateway. Try again shortly."
					});
					break;
				}
				if (res.status === 402) {
					send({
						type: "error",
						agent: agent.id,
						message: "AI credits exhausted on this workspace. Add credits to continue."
					});
					break;
				}
				if (!res.ok || !res.body) {
					const text = await res.text().catch(() => "");
					send({
						type: "error",
						agent: agent.id,
						message: `Gateway error ${res.status}: ${text.slice(0, 200)}`
					});
					break;
				}
				const reader = res.body.getReader();
				const decoder = new TextDecoder();
				let buffer = "";
				let full = "";
				while (true) {
					const { value, done } = await reader.read();
					if (done) break;
					buffer += decoder.decode(value, { stream: true });
					const lines = buffer.split("\n");
					buffer = lines.pop() ?? "";
					for (const line of lines) {
						const trimmed = line.trim();
						if (!trimmed.startsWith("data:")) continue;
						const data = trimmed.slice(5).trim();
						if (data === "[DONE]") continue;
						try {
							const delta = JSON.parse(data).choices?.[0]?.delta?.content;
							if (delta) {
								full += delta;
								send({
									type: "token",
									agent: agent.id,
									delta
								});
							}
						} catch {}
					}
				}
				prior[agent.id] = full;
				send({
					type: "agent_done",
					agent: agent.id,
					content: full
				});
			}
			send({
				type: "done",
				ts: Date.now()
			});
		} catch (err) {
			send({
				type: "error",
				message: err instanceof Error ? err.message : String(err)
			});
		} finally {
			controller.close();
		}
	} });
	return new Response(stream, { headers: {
		"Content-Type": "text/event-stream",
		"Cache-Control": "no-cache, no-transform",
		Connection: "keep-alive"
	} });
} } } });
var Index_tempRoute = Route$3.update({
	id: "/index_temp",
	path: "/index_temp",
	getParentRoute: () => Route$4
});
var IndexBackupRoute = Route$2.update({
	id: "/index-backup",
	path: "/index-backup",
	getParentRoute: () => Route$4
});
var rootRouteChildren = {
	IndexRoute: Route$1.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$4
	}),
	IndexBackupRoute,
	Index_tempRoute,
	ApiAnalyzeRoute: Route.update({
		id: "/api/analyze",
		path: "/api/analyze",
		getParentRoute: () => Route$4
	})
};
var routeTree = Route$4._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
