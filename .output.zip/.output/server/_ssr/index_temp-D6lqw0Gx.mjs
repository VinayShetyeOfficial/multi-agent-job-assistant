import { o as __toESM } from "../_runtime.mjs";
import { r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { t as require_jsx_dev_runtime } from "../_libs/react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as X, t as Zap } from "../_libs/lucide-react.mjs";
import { n as Toaster$1, t as ResumeUpload } from "./ResumeUpload-D038Z0JC.mjs";
import { t as Markdown } from "../_libs/react-markdown+[...].mjs";
import { t as remarkGfm } from "../_libs/remark-gfm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/index_temp-D6lqw0Gx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_dev_runtime = require_jsx_dev_runtime();
var _jsxFileName = "E:/2. Job Search [USA🗽]/5. ⭐Wynisco⭐/4. Onboarding/3. Technical Prep/z. Projects/Multi AI Agents with Langgraph/multi-agent-job-assistant/src/routes/index_temp.tsx?tsr-split=component";
var AGENT_META = {
	supervisor: {
		label: "Supervisor",
		short: "SUP",
		color: "text-accent",
		description: "Routes tasks across the agent graph"
	},
	researcher: {
		label: "Researcher",
		short: "RES",
		color: "text-[color:var(--agent-researcher)]",
		description: "Company & market intelligence",
		tool: "web_search"
	},
	matcher: {
		label: "Matcher",
		short: "MAT",
		color: "text-[color:var(--agent-matcher)]",
		description: "Resume ↔ JD gap analysis",
		tool: "read_resume"
	},
	prep: {
		label: "Prep Agent",
		short: "PREP",
		color: "text-[color:var(--agent-prep)]",
		description: "Interview prep synthesis"
	}
};
var AGENT_ORDER = [
	"supervisor",
	"researcher",
	"matcher",
	"prep"
];
var SAMPLE_JD = `Role: Senior Backend Engineer — Distributed Systems
Company: Northstar Labs (Series C, real-time infra)

We're looking for an engineer to own the core event pipeline that
powers our low-latency trading analytics platform. You'll design
gRPC services in Rust, deploy Kubernetes operators, and work
closely with the ML platform team on feature-store latency.

Requirements:
- 5+ years backend experience, ideally in Rust or Go
- Deep understanding of distributed systems (consensus, sharding)
- Experience running Kubernetes at scale, ideally with custom operators
- Comfortable with observability: Prometheus, OpenTelemetry
- Bonus: prior exposure to feature stores or ML infra`;
function Index() {
	const [jd, setJd] = (0, import_react.useState)(SAMPLE_JD);
	const [resume, setResume] = (0, import_react.useState)("");
	const [running, setRunning] = (0, import_react.useState)(false);
	const [trace, setTrace] = (0, import_react.useState)([]);
	const [agents, setAgents] = (0, import_react.useState)({
		supervisor: {
			status: "idle",
			output: ""
		},
		researcher: {
			status: "idle",
			output: ""
		},
		matcher: {
			status: "idle",
			output: ""
		},
		prep: {
			status: "idle",
			output: ""
		}
	});
	const [startTs, setStartTs] = (0, import_react.useState)(null);
	const [elapsed, setElapsed] = (0, import_react.useState)(0);
	const traceScrollRef = (0, import_react.useRef)(null);
	const abortRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!running || startTs == null) return;
		const id = setInterval(() => setElapsed(Date.now() - startTs), 100);
		return () => clearInterval(id);
	}, [running, startTs]);
	(0, import_react.useEffect)(() => {
		const el = traceScrollRef.current;
		if (el) el.scrollTop = el.scrollHeight;
	}, [trace]);
	const matchScore = (0, import_react.useMemo)(() => {
		const m = agents.matcher.output.match(/(\d{2,3})\s*%/);
		if (!m) return null;
		const n = parseInt(m[1], 10);
		if (isNaN(n)) return null;
		return Math.min(100, Math.max(0, n));
	}, [agents.matcher.output]);
	const gaps = (0, import_react.useMemo)(() => extractSection(agents.matcher.output, "Gaps"), [agents.matcher.output]);
	const suggestedQuestion = (0, import_react.useMemo)(() => {
		return extractBullets(agents.prep.output, "Likely Technical Questions")[0] ?? null;
	}, [agents.prep.output]);
	const reset = (0, import_react.useCallback)(() => {
		setTrace([]);
		setAgents({
			supervisor: {
				status: "idle",
				output: ""
			},
			researcher: {
				status: "idle",
				output: ""
			},
			matcher: {
				status: "idle",
				output: ""
			},
			prep: {
				status: "idle",
				output: ""
			}
		});
		setElapsed(0);
		setStartTs(null);
	}, []);
	const start = (0, import_react.useCallback)(async () => {
		if (running) return;
		if (jd.trim().length < 20) {
			toast.error("Paste a longer job description to run the graph.");
			return;
		}
		if (resume.trim().length < 50) {
			toast.error("Please upload or paste your resume to get personalized analysis.");
			return;
		}
		reset();
		setRunning(true);
		setStartTs(Date.now());
		const controller = new AbortController();
		abortRef.current = controller;
		let idCounter = 0;
		const pushTrace = (t) => setTrace((prev) => [...prev, {
			...t,
			id: `t${idCounter++}`
		}]);
		try {
			const res = await fetch("/api/analyze", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					jd,
					resume
				}),
				signal: controller.signal
			});
			if (!res.ok || !res.body) {
				const msg = await res.text().catch(() => "");
				throw new Error(msg || `Request failed (${res.status})`);
			}
			const reader = res.body.getReader();
			const decoder = new TextDecoder();
			let buf = "";
			while (true) {
				const { value, done } = await reader.read();
				if (done) break;
				buf += decoder.decode(value, { stream: true });
				const chunks = buf.split("\n\n");
				buf = chunks.pop() ?? "";
				for (const chunk of chunks) {
					const line = chunk.trim();
					if (!line.startsWith("data:")) continue;
					const raw = line.slice(5).trim();
					if (!raw) continue;
					let evt;
					try {
						evt = JSON.parse(raw);
					} catch {
						continue;
					}
					if (evt.type === "agent_start") {
						const id = evt.agent;
						setAgents((a) => ({
							...a,
							[id]: {
								...a[id],
								status: "running",
								output: "",
								startedAt: Date.now()
							}
						}));
						pushTrace({
							agent: id,
							kind: "info",
							text: `[${AGENT_META[id].label.toUpperCase()}] node activated`
						});
						const tool = AGENT_META[id].tool;
						if (tool) pushTrace({
							agent: id,
							kind: "tool",
							text: `tool.invoke(${tool}) → streaming`
						});
					} else if (evt.type === "token") {
						const id = evt.agent;
						const delta = String(evt.delta ?? "");
						setAgents((a) => ({
							...a,
							[id]: {
								...a[id],
								output: a[id].output + delta
							}
						}));
					} else if (evt.type === "agent_done") {
						const id = evt.agent;
						setAgents((a) => ({
							...a,
							[id]: {
								...a[id],
								status: "done",
								output: evt.content ?? a[id].output,
								finishedAt: Date.now()
							}
						}));
						pushTrace({
							agent: id,
							kind: "result",
							text: `[${AGENT_META[id].label.toUpperCase()}] finished (${(evt.content ?? "").length} chars)`
						});
					} else if (evt.type === "error") {
						const id = evt.agent ?? "supervisor";
						setAgents((a) => ({
							...a,
							[id]: {
								...a[id],
								status: "error"
							}
						}));
						pushTrace({
							agent: id,
							kind: "error",
							text: `ERROR: ${evt.message}`
						});
						toast.error(evt.message ?? "Agent error");
					} else if (evt.type === "done") pushTrace({
						agent: "supervisor",
						kind: "info",
						text: `[SUPERVISOR] graph complete → case file compiled`
					});
				}
			}
		} catch (err) {
			if (err.name === "AbortError") return;
			const msg = err instanceof Error ? err.message : String(err);
			toast.error(msg);
			pushTrace({
				agent: "supervisor",
				kind: "error",
				text: `FATAL: ${msg}`
			});
		} finally {
			setRunning(false);
			abortRef.current = null;
		}
	}, [
		jd,
		resume,
		reset,
		running
	]);
	const stop = (0, import_react.useCallback)(() => {
		abortRef.current?.abort();
		setRunning(false);
	}, []);
	const [showTrace, setShowTrace] = (0, import_react.useState)(false);
	const [showReports, setShowReports] = (0, import_react.useState)(true);
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "h-screen flex flex-col bg-background text-foreground font-sans overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Toaster$1, {
				theme: "dark",
				richColors: true,
				position: "top-right"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 298,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("nav", {
				className: "flex-shrink-0 h-14 border-b border-border bg-background/95 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "h-full flex items-center justify-between px-6",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-8",
						children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "grid size-6 place-items-center rounded-sm bg-accent",
								children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "size-2 rounded-[1px] bg-background" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 306,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 305,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "font-mono text-sm font-bold tracking-tighter text-accent",
								children: [
									"AGENTIC.OS ",
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "text-muted-foreground",
										children: "//"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 309,
										columnNumber: 28
									}, this),
									" RECRUIT"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 308,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 304,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 303,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: `size-1.5 rounded-full ${running ? "bg-accent animate-pulse" : "bg-muted-foreground"}` }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 315,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "font-mono text-[10px] uppercase text-muted-foreground",
								children: running ? "EXECUTING" : "READY"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 316,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 314,
							columnNumber: 13
						}, this), elapsed > 0 && /* @__PURE__ */ (void 0)("span", {
							className: "font-mono text-[10px] text-accent",
							children: [(elapsed / 1e3).toFixed(1), "s"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 320,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 313,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 302,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 301,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "flex-1 grid lg:grid-cols-[40%_60%] overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "overflow-y-auto p-6 space-y-6 border-r border-border",
					children: [
						!running && /* @__PURE__ */ (void 0)("div", {
							className: "text-center py-8",
							children: [/* @__PURE__ */ (void 0)("h1", {
								className: "text-5xl font-bold leading-tight",
								children: [
									"Orchestrate your",
									/* @__PURE__ */ (void 0)("br", {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 335,
										columnNumber: 17
									}, this),
									"next ",
									/* @__PURE__ */ (void 0)("span", {
										className: "text-accent",
										children: "hire."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 336,
										columnNumber: 22
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 333,
								columnNumber: 15
							}, this), /* @__PURE__ */ (void 0)("p", {
								className: "mt-4 text-sm text-muted-foreground max-w-md mx-auto",
								children: "Upload your resume and paste a job description. Watch AI agents analyze fit, research companies, and generate interview prep in real-time."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 338,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 332,
							columnNumber: 24
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex flex-wrap gap-2 justify-center",
							children: AGENT_ORDER.map((id) => {
								const meta = AGENT_META[id];
								const state = agents[id];
								return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: `flex items-center gap-2 px-3 py-1.5 rounded border font-mono text-xs ${state.status === "running" ? "border-accent bg-accent/10 text-accent" : state.status === "done" ? "border-accent/40 bg-accent/5 text-accent" : "border-border bg-background text-muted-foreground"}`,
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "font-bold",
										children: meta.short
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 349,
										columnNumber: 19
									}, this), state.status === "running" && /* @__PURE__ */ (void 0)("span", { className: "size-1.5 rounded-full bg-accent animate-pulse" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 350,
										columnNumber: 50
									}, this)]
								}, id, true, {
									fileName: _jsxFileName,
									lineNumber: 348,
									columnNumber: 20
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 344,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "rounded-xl border border-border bg-card p-1",
							children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "rounded-lg bg-background p-4",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "mb-3 flex items-center justify-between border-b border-border pb-2",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "font-mono text-[10px] uppercase tracking-wider text-accent",
										children: "RESUME.pdf"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 359,
										columnNumber: 17
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "font-mono text-[10px] text-muted-foreground",
										children: [resume.length.toLocaleString(), " chars"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 362,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 358,
									columnNumber: 15
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ResumeUpload, {
									onResumeChange: setResume,
									resume,
									disabled: running
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 366,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 357,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 356,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "rounded-xl border border-border bg-card p-1",
							children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "rounded-lg bg-background p-4",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "mb-3 flex items-center justify-between border-b border-border pb-2",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "font-mono text-[10px] uppercase tracking-wider text-secondary",
										children: "JOB_DESCRIPTION.txt"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 374,
										columnNumber: 17
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
											className: "font-mono text-[10px] text-muted-foreground",
											children: [jd.length.toLocaleString(), " chars"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 378,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
											type: "button",
											onClick: () => setJd(SAMPLE_JD),
											className: "font-mono text-[10px] text-accent hover:underline",
											children: "LOAD SAMPLE"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 381,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 377,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 373,
									columnNumber: 15
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("textarea", {
									value: jd,
									onChange: (e) => setJd(e.target.value),
									placeholder: "Paste the job description here...",
									className: "h-48 w-full resize-none border-none bg-transparent font-mono text-sm leading-relaxed text-foreground placeholder:text-muted-foreground/40 focus:outline-none"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 386,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 372,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 371,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex gap-3",
							children: running ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
								onClick: stop,
								className: "flex-1 flex items-center justify-center gap-2 rounded bg-destructive/10 border border-destructive/40 px-6 py-3 font-mono text-sm font-bold uppercase tracking-wider text-destructive hover:bg-destructive/20 transition-colors",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(X, { className: "size-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 393,
									columnNumber: 17
								}, this), "ABORT"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 392,
								columnNumber: 24
							}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
								onClick: start,
								disabled: !resume.trim() || !jd.trim(),
								className: "flex-1 flex items-center justify-center gap-2 rounded bg-accent px-6 py-3 font-mono text-sm font-bold uppercase tracking-wider text-accent-foreground shadow-lg shadow-accent/20 hover:bg-accent/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Zap, { className: "size-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 396,
									columnNumber: 17
								}, this), "START ANALYSIS"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 395,
								columnNumber: 27
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 391,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 330,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "overflow-y-auto p-6 space-y-6",
					children: [
						matchScore !== null && /* @__PURE__ */ (void 0)("div", {
							className: "rounded-xl border border-border bg-card p-8 text-center",
							children: [
								/* @__PURE__ */ (void 0)("div", {
									className: "font-mono text-[10px] uppercase tracking-widest text-muted-foreground mb-4",
									children: "MATCH SCORE"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 406,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ (void 0)("div", {
									className: "font-mono text-8xl font-bold tabular-nums text-accent",
									children: [matchScore, /* @__PURE__ */ (void 0)("span", {
										className: "text-4xl text-muted-foreground",
										children: "%"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 411,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 409,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ (void 0)("div", {
									className: "mt-6 h-3 w-full overflow-hidden rounded-full bg-border",
									children: /* @__PURE__ */ (void 0)("div", {
										className: "h-full bg-accent transition-all duration-1000",
										style: { width: `${matchScore}%` }
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 414,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 413,
									columnNumber: 15
								}, this),
								matchScore >= 70 && /* @__PURE__ */ (void 0)("div", {
									className: "mt-4 flex items-center justify-center gap-2 text-sm text-accent",
									children: [/* @__PURE__ */ (void 0)("span", {
										className: "text-2xl",
										children: "✓"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 419,
										columnNumber: 19
									}, this), /* @__PURE__ */ (void 0)("span", { children: "Strong candidate match" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 420,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 418,
									columnNumber: 36
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 405,
							columnNumber: 35
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "rounded-xl border border-border bg-card p-5",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "flex items-center justify-between mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "font-mono text-[10px] uppercase tracking-widest text-muted-foreground",
									children: "Graph Topology"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 427,
									columnNumber: 15
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "font-mono text-[10px] text-accent",
									children: running ? "LIVE" : "IDLE"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 430,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 426,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "flex flex-col items-center gap-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(GraphNode, {
										id: "supervisor",
										state: agents.supervisor,
										width: "w-32",
										primary: true
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 433,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "relative w-full flex justify-center",
										children: [
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-0 left-1/2 -translate-x-1/2 h-4 w-px bg-border" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 435,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-4 left-[16.66%] right-[16.66%] h-px bg-border" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 436,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-4 left-[16.66%] h-4 w-px bg-border" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 437,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-4 left-1/2 -translate-x-1/2 h-4 w-px bg-border" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 438,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-4 right-[16.66%] h-4 w-px bg-border" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 439,
												columnNumber: 17
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 434,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "grid w-full grid-cols-3 gap-2",
										children: [
											"researcher",
											"matcher",
											"prep"
										].map((id) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(GraphNode, {
											id,
											state: agents[id]
										}, id, false, {
											fileName: _jsxFileName,
											lineNumber: 442,
											columnNumber: 77
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 441,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 432,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 425,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "rounded-xl border border-border bg-card p-5",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "font-mono text-[10px] uppercase tracking-widest text-muted-foreground mb-4",
								children: "Key Gaps Identified"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 449,
								columnNumber: 13
							}, this), gaps.length === 0 ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "font-mono text-xs text-muted-foreground/60",
								children: agents.matcher.status === "done" ? "✓ No blocking gaps identified." : "⋯ Awaiting matcher analysis…"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 452,
								columnNumber: 34
							}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("ul", {
								className: "space-y-3 max-h-[300px] overflow-y-auto",
								children: gaps.map((g, i) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("li", {
									className: "flex items-start gap-3 text-sm leading-6",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "shrink-0 font-mono text-xs text-destructive",
										children: [
											"[",
											i + 1,
											"]"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 456,
										columnNumber: 21
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "min-w-0 text-muted-foreground/95",
										children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Markdown, {
											remarkPlugins: [remarkGfm],
											components: {
												p: ({ node, ...props }) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { ...props }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 462,
													columnNumber: 25
												}, this),
												strong: ({ node, ...props }) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("strong", {
													className: "font-semibold text-foreground",
													...props
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 466,
													columnNumber: 25
												}, this)
											},
											children: g
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 458,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 457,
										columnNumber: 21
									}, this)]
								}, i, true, {
									fileName: _jsxFileName,
									lineNumber: 455,
									columnNumber: 37
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 454,
								columnNumber: 22
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 448,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "rounded-xl bg-accent p-5 text-accent-foreground shadow-lg shadow-accent/20",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "font-mono text-[10px] font-bold uppercase tracking-widest mb-3",
								children: "Suggested Prep Question"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 477,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "text-sm font-medium leading-relaxed",
								children: suggestedQuestion ? `"${suggestedQuestion}"` : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "opacity-70",
									children: "Prep agent will generate a tailored question here."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 481,
									columnNumber: 63
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 480,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 476,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 403,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 328,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "flex-shrink-0 border-t border-border bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
					onClick: () => setShowTrace(!showTrace),
					className: "w-full flex items-center justify-between px-6 py-3 hover:bg-background/50 transition-colors",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "font-mono text-[10px] uppercase tracking-widest text-muted-foreground",
							children: [showTrace ? "▼" : "▶", " Execution Trace"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 495,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "font-mono text-[9px] text-muted-foreground/60",
							children: [trace.length, " events"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 498,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 494,
						columnNumber: 13
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "font-mono text-[10px] text-accent",
						children: [(elapsed / 1e3).toFixed(1), "s ELAPSED"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 502,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 493,
					columnNumber: 11
				}, this), showTrace && /* @__PURE__ */ (void 0)("div", {
					ref: traceScrollRef,
					className: "grid-bg scanline max-h-[300px] overflow-y-auto px-6 pb-4 space-y-2 font-mono text-xs",
					children: [
						trace.length === 0 && !running ? /* @__PURE__ */ (void 0)("div", {
							className: "flex h-32 items-center justify-center text-muted-foreground",
							children: /* @__PURE__ */ (void 0)("p", {
								className: "text-xs",
								children: "Awaiting execution..."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 508,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 507,
							columnNumber: 49
						}, this) : trace.map((t) => /* @__PURE__ */ (void 0)(TraceLine, { entry: t }, t.id, false, {
							fileName: _jsxFileName,
							lineNumber: 509,
							columnNumber: 41
						}, this)),
						AGENT_ORDER.filter((id) => agents[id].status === "running").map((id) => /* @__PURE__ */ (void 0)("div", {
							className: "animate-stream rounded border border-border/60 bg-background/60 p-3",
							children: [/* @__PURE__ */ (void 0)("div", {
								className: "mb-2 flex items-center gap-2",
								children: [/* @__PURE__ */ (void 0)("span", {
									className: `font-mono text-[10px] font-bold ${AGENT_META[id].color}`,
									children: [
										"[",
										AGENT_META[id].label.toUpperCase(),
										"]"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 512,
									columnNumber: 21
								}, this), /* @__PURE__ */ (void 0)("span", { className: "ml-auto size-1.5 animate-pulse rounded-full bg-accent" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 515,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 511,
								columnNumber: 19
							}, this), /* @__PURE__ */ (void 0)("div", {
								className: "text-[11px] text-foreground/90 whitespace-pre-wrap break-words",
								children: agents[id].output || "thinking..."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 517,
								columnNumber: 19
							}, this)]
						}, `stream-${id}`, true, {
							fileName: _jsxFileName,
							lineNumber: 510,
							columnNumber: 84
						}, this)),
						/* @__PURE__ */ (void 0)("div", { className: "scanline-bar" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 521,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 506,
					columnNumber: 25
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 492,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
					onClick: () => setShowReports(!showReports),
					className: "w-full flex items-center justify-between px-6 py-3 hover:bg-background/50 transition-colors border-t border-border",
					children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "font-mono text-[10px] uppercase tracking-widest text-muted-foreground",
							children: [showReports ? "▼" : "▶", " Agent Reports"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 529,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "font-mono text-[9px] text-accent",
							children: [AGENT_ORDER.filter((id) => agents[id].status === "done").length, " / 3 COMPLETE"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 532,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 528,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 527,
					columnNumber: 11
				}, this), showReports && /* @__PURE__ */ (void 0)("div", {
					className: "p-6 grid grid-cols-1 md:grid-cols-3 gap-4 max-h-[400px] overflow-y-auto",
					children: [
						"researcher",
						"matcher",
						"prep"
					].map((id) => /* @__PURE__ */ (void 0)(ArtifactCard, {
						id,
						state: agents[id]
					}, id, false, {
						fileName: _jsxFileName,
						lineNumber: 538,
						columnNumber: 75
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 537,
					columnNumber: 27
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 526,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 490,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 297,
		columnNumber: 10
	}, this);
}
//#endregion
export { Index as component };
