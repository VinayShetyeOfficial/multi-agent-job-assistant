import { o as __toESM } from "../_runtime.mjs";
import { r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { t as require_jsx_dev_runtime } from "../_libs/react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SquareTerminal, c as LayoutDashboard, f as CircleAlert, l as FileText, n as X, o as Maximize2, p as Activity, t as Zap, u as CircleCheck } from "../_libs/lucide-react.mjs";
import { n as Toaster$1, t as ResumeUpload } from "./ResumeUpload-D038Z0JC.mjs";
import { t as Markdown } from "../_libs/react-markdown+[...].mjs";
import { t as remarkGfm } from "../_libs/remark-gfm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D2hLxTs-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_dev_runtime = require_jsx_dev_runtime();
var _jsxFileName = "E:/2. Job Search [USA🗽]/5. ⭐Wynisco⭐/4. Onboarding/3. Technical Prep/z. Projects/Multi AI Agents with Langgraph/multi-agent-job-assistant/src/routes/index.tsx?tsr-split=component";
var AGENT_META = {
	supervisor: {
		label: "Supervisor",
		short: "SUP",
		color: "text-emerald-400",
		border: "border-emerald-500/50"
	},
	researcher: {
		label: "Researcher",
		short: "RES",
		color: "text-blue-400",
		border: "border-blue-500/50",
		tool: "web_search"
	},
	matcher: {
		label: "Matcher",
		short: "MAT",
		color: "text-purple-400",
		border: "border-purple-500/50",
		tool: "read_resume"
	},
	prep: {
		label: "Prep Agent",
		short: "PREP",
		color: "text-amber-400",
		border: "border-amber-500/50"
	}
};
var AGENT_ORDER = [
	"supervisor",
	"researcher",
	"matcher",
	"prep"
];
var SAMPLE_JD = `Role: Senior Backend Engineer — Distributed Systems
Company: Northstar Labs (Series C, real-time infra)

We're looking for an engineer to own the core event pipeline that
powers our low-latency trading analytics platform. You'll design
gRPC services in Rust, deploy Kubernetes operators, and work
closely with the ML platform team on feature-store latency.

Requirements:
- 5+ years backend experience, ideally in Rust or Go
- Deep understanding of distributed systems (consensus, sharding)
- Experience running Kubernetes at scale, ideally with custom operators
- Comfortable with observability: Prometheus, OpenTelemetry
- Bonus: prior exposure to feature stores or ML infra`;
var formatSupervisorOutput = (rawText) => {
	if (!rawText) return "";
	let text = rawText;
	text = text.replace(/•/g, "");
	text = text.replace(/(Candidate:)/gi, "\n\n**Candidate:**");
	text = text.replace(/(Role:)/gi, "\n\n**Role:**");
	text = text.replace(/(Company\/Stack:)/gi, "\n\n**Company/Stack:**");
	text = text.replace(/(Dispatch → [A-Z]+:)/gi, "\n\n### $1\n");
	text = text.replace(/\n{3,}/g, "\n\n");
	return text.trim();
};
function Index() {
	const [jd, setJd] = (0, import_react.useState)(SAMPLE_JD);
	const [resume, setResume] = (0, import_react.useState)("");
	const [running, setRunning] = (0, import_react.useState)(false);
	const [trace, setTrace] = (0, import_react.useState)([]);
	const [agents, setAgents] = (0, import_react.useState)({
		supervisor: {
			status: "idle",
			output: ""
		},
		researcher: {
			status: "idle",
			output: ""
		},
		matcher: {
			status: "idle",
			output: ""
		},
		prep: {
			status: "idle",
			output: ""
		}
	});
	const [startTs, setStartTs] = (0, import_react.useState)(null);
	const [elapsed, setElapsed] = (0, import_react.useState)(0);
	const traceScrollRef = (0, import_react.useRef)(null);
	const abortRef = (0, import_react.useRef)(null);
	const [viewingOutput, setViewingOutput] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!running || startTs == null) return;
		const id = setInterval(() => setElapsed(Date.now() - startTs), 100);
		return () => clearInterval(id);
	}, [running, startTs]);
	(0, import_react.useEffect)(() => {
		const el = traceScrollRef.current;
		if (el) el.scrollTop = el.scrollHeight;
	}, [trace]);
	const matchScore = (0, import_react.useMemo)(() => {
		const m = agents.matcher.output.match(/(\d{2,3})\s*%/);
		if (!m) return null;
		const n = parseInt(m[1], 10);
		if (isNaN(n)) return null;
		return Math.min(100, Math.max(0, n));
	}, [agents.matcher.output]);
	const gaps = (0, import_react.useMemo)(() => extractSection(agents.matcher.output, "Gaps"), [agents.matcher.output]);
	const reset = (0, import_react.useCallback)(() => {
		setTrace([]);
		setAgents({
			supervisor: {
				status: "idle",
				output: ""
			},
			researcher: {
				status: "idle",
				output: ""
			},
			matcher: {
				status: "idle",
				output: ""
			},
			prep: {
				status: "idle",
				output: ""
			}
		});
		setElapsed(0);
		setStartTs(null);
	}, []);
	const start = (0, import_react.useCallback)(async () => {
		if (running) return;
		if (jd.trim().length < 20) {
			toast.error("Paste a longer job description to run the graph.");
			return;
		}
		if (resume.trim().length < 50) {
			toast.error("Please upload or paste your resume to get personalized analysis.");
			return;
		}
		reset();
		setRunning(true);
		setStartTs(Date.now());
		const controller = new AbortController();
		abortRef.current = controller;
		let idCounter = 0;
		const pushTrace = (t) => setTrace((prev) => [...prev, {
			...t,
			id: `t${idCounter++}`
		}]);
		try {
			const res = await fetch("/api/analyze", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					jd,
					resume
				}),
				signal: controller.signal
			});
			if (!res.ok || !res.body) {
				const msg = await res.text().catch(() => "");
				throw new Error(msg || `Request failed (${res.status})`);
			}
			const reader = res.body.getReader();
			const decoder = new TextDecoder();
			let buf = "";
			while (true) {
				const { value, done } = await reader.read();
				if (done) break;
				buf += decoder.decode(value, { stream: true });
				const chunks = buf.split("\n\n");
				buf = chunks.pop() ?? "";
				for (const chunk of chunks) {
					const line = chunk.trim();
					if (!line.startsWith("data:")) continue;
					const raw = line.slice(5).trim();
					if (!raw) continue;
					let evt;
					try {
						evt = JSON.parse(raw);
					} catch {
						continue;
					}
					if (evt.type === "agent_start") {
						const id = evt.agent;
						setAgents((a) => ({
							...a,
							[id]: {
								...a[id],
								status: "running",
								output: "",
								startedAt: Date.now()
							}
						}));
						pushTrace({
							agent: id,
							kind: "info",
							text: `[${AGENT_META[id].label.toUpperCase()}] node activated`
						});
					} else if (evt.type === "token") {
						const id = evt.agent;
						const delta = String(evt.delta ?? "");
						setAgents((a) => ({
							...a,
							[id]: {
								...a[id],
								output: a[id].output + delta
							}
						}));
					} else if (evt.type === "agent_done") {
						const id = evt.agent;
						setAgents((a) => ({
							...a,
							[id]: {
								...a[id],
								status: "done",
								output: evt.content ?? a[id].output,
								finishedAt: Date.now()
							}
						}));
						pushTrace({
							agent: id,
							kind: "result",
							text: `[${AGENT_META[id].label.toUpperCase()}] finished`
						});
					} else if (evt.type === "error") {
						const id = evt.agent ?? "supervisor";
						setAgents((a) => ({
							...a,
							[id]: {
								...a[id],
								status: "error"
							}
						}));
						pushTrace({
							agent: id,
							kind: "error",
							text: `ERROR: ${evt.message}`
						});
						toast.error(evt.message ?? "Agent error");
					} else if (evt.type === "done") pushTrace({
						agent: "supervisor",
						kind: "info",
						text: `[SUPERVISOR] graph complete → case file compiled`
					});
				}
			}
		} catch (err) {
			if (err.name === "AbortError") return;
			const msg = err instanceof Error ? err.message : String(err);
			toast.error(msg);
			pushTrace({
				agent: "supervisor",
				kind: "error",
				text: `FATAL: ${msg}`
			});
		} finally {
			setRunning(false);
			abortRef.current = null;
		}
	}, [
		jd,
		resume,
		reset,
		running
	]);
	const stop = (0, import_react.useCallback)(() => {
		abortRef.current?.abort();
		setRunning(false);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "flex h-screen w-full flex-col font-sans overflow-hidden bg-slate-950 text-slate-200",
		children: [
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Toaster$1, {
				theme: "dark",
				richColors: true,
				position: "top-right"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 308,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("nav", {
				className: "h-14 shrink-0 flex items-center justify-between border-b border-slate-800 bg-slate-900 px-6 z-20 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "grid size-7 place-items-center rounded bg-emerald-600 shadow-[0_0_15px_rgba(16,185,129,0.3)]",
						children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(LayoutDashboard, { className: "size-4 text-white" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 314,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 313,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "font-mono text-sm font-bold tracking-tight text-slate-100",
						children: [
							"AGENTIC.OS ",
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "text-slate-600 font-normal mx-1",
								children: "/"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 317,
								columnNumber: 24
							}, this),
							" RECRUIT"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 316,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 312,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-2 rounded border border-slate-700 bg-slate-950 px-3 py-1.5 shadow-inner",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: `size-2.5 rounded-full ${running ? "bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.8)]" : "bg-slate-600"}` }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 322,
							columnNumber: 13
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "font-mono text-[11px] uppercase font-semibold text-slate-400",
							children: running ? "SYSTEM ACTIVE" : "SYSTEM IDLE"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 323,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 321,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "font-mono text-sm text-emerald-400 font-bold w-16 text-right tabular-nums",
						children: [(elapsed / 1e3).toFixed(1), "s"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 327,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 320,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 311,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "flex flex-1 overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("aside", {
					className: "w-[450px] shrink-0 border-r border-slate-800 bg-slate-900/50 flex flex-col z-10 overflow-y-auto",
					children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "p-6 flex flex-col gap-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
								className: "font-mono text-sm font-bold uppercase tracking-widest text-slate-200 flex items-center gap-2 mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(FileText, { className: "size-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 343,
									columnNumber: 17
								}, this), "Input Parameters"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 342,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "text-xs text-slate-400 leading-relaxed",
								children: "Provide target role constraints and candidate context to initiate the agentic workflow."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 346,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 341,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "flex flex-col gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
										className: "font-mono text-xs uppercase font-bold tracking-wider text-slate-300",
										children: "Candidate Resume"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 354,
										columnNumber: 17
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "font-mono text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700",
										children: [resume.length.toLocaleString(), " chars"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 357,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 353,
									columnNumber: 15
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "rounded border border-slate-800 bg-slate-950 p-4 shadow-inner",
									children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ResumeUpload, {
										onResumeChange: setResume,
										resume,
										disabled: running
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 362,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 361,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 352,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "flex flex-col gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
										className: "font-mono text-xs uppercase font-bold tracking-wider text-slate-300",
										children: "Target Description"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 369,
										columnNumber: 17
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
										onClick: () => setJd(SAMPLE_JD),
										className: "font-mono text-[10px] text-emerald-400 hover:text-emerald-300 hover:underline transition-all font-semibold",
										children: "LOAD SAMPLE"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 372,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 368,
									columnNumber: 15
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "rounded border border-slate-800 bg-slate-950 shadow-inner overflow-hidden focus-within:border-emerald-500/50 transition-colors",
									children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("textarea", {
										value: jd,
										onChange: (e) => setJd(e.target.value),
										placeholder: "Paste the job description here...",
										className: "h-56 w-full resize-none bg-transparent p-4 font-mono text-xs leading-relaxed text-slate-300 placeholder:text-slate-600 focus:outline-none"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 377,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 376,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 367,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "pt-2",
								children: running ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
									onClick: stop,
									className: "w-full flex items-center justify-center gap-2 rounded bg-red-950/40 border border-red-500/50 px-4 py-4 font-mono text-sm font-bold uppercase tracking-wider text-red-400 hover:bg-red-900/40 transition-all",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(X, { className: "size-4.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 384,
										columnNumber: 19
									}, this), "Terminate Graph"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 383,
									columnNumber: 26
								}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
									onClick: start,
									disabled: !resume.trim() || !jd.trim(),
									className: "w-full flex items-center justify-center gap-2 rounded bg-emerald-600 px-4 py-4 font-mono text-sm font-bold uppercase tracking-wider text-white shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:shadow-[0_0_25px_rgba(16,185,129,0.5)] hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Zap, { className: "size-4.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 387,
										columnNumber: 19
									}, this), "Execute Analysis"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 386,
									columnNumber: 29
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 382,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 338,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 337,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("main", {
					className: "flex-1 flex flex-col min-w-0 bg-slate-950",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex-1 flex min-h-0 border-b border-slate-800 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-slate-950 relative overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute inset-0 bg-[linear-gradient(to_right,#8080801a_1px,transparent_1px),linear-gradient(to_bottom,#8080801a_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 401,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "flex-1 flex flex-col items-center justify-center p-8 relative z-10",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "absolute top-6 left-8 font-mono text-xs uppercase font-bold tracking-widest text-slate-500 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Activity, { className: "size-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 406,
										columnNumber: 17
									}, this), "Graph Topology"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 405,
									columnNumber: 15
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "flex flex-col items-center w-full max-w-3xl mx-auto mt-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "z-10 w-48",
											children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(GraphNode, {
												id: "supervisor",
												state: agents.supervisor,
												primary: true,
												onView: () => setViewingOutput("supervisor")
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 414,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 413,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "relative w-full h-16 -my-px pointer-events-none flex justify-center",
											children: [
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-0 w-[2px] h-8 bg-slate-700" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 419,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-8 left-[calc(100%/6)] right-[calc(100%/6)] h-[2px] bg-slate-700" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 420,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-8 left-[calc(100%/6)] w-[2px] h-8 bg-slate-700 -translate-x-1/2" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 421,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-8 left-1/2 w-[2px] h-8 bg-slate-700 -translate-x-1/2" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 422,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-8 right-[calc(100%/6)] w-[2px] h-8 bg-slate-700 translate-x-1/2" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 423,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 418,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "grid grid-cols-3 w-full gap-6 z-10",
											children: [
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
													className: "flex justify-center",
													children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
														className: "w-full max-w-[180px]",
														children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(GraphNode, {
															id: "researcher",
															state: agents.researcher,
															onView: () => setViewingOutput("researcher")
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 430,
															columnNumber: 23
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 429,
														columnNumber: 21
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 428,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
													className: "flex justify-center",
													children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
														className: "w-full max-w-[180px]",
														children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(GraphNode, {
															id: "matcher",
															state: agents.matcher,
															onView: () => setViewingOutput("matcher")
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 435,
															columnNumber: 23
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 434,
														columnNumber: 21
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 433,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
													className: "flex justify-center",
													children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
														className: "w-full max-w-[180px]",
														children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(GraphNode, {
															id: "prep",
															state: agents.prep,
															onView: () => setViewingOutput("prep")
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 440,
															columnNumber: 23
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 439,
														columnNumber: 21
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 438,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 427,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 411,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 404,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "w-[400px] shrink-0 border-l border-slate-800 bg-slate-900/80 p-6 flex flex-col gap-5 overflow-y-auto relative z-10",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "font-mono text-xs uppercase font-bold tracking-widest text-slate-500",
										children: "Case Summary"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 449,
										columnNumber: 16
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "rounded-lg border border-slate-700 bg-slate-950 p-4 flex flex-col items-center justify-center relative shadow-lg shrink-0",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "font-mono text-[10px] uppercase tracking-wider text-slate-400 mb-1",
											children: "Total Match"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 455,
											columnNumber: 18
										}, this), matchScore !== null ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(import_jsx_dev_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "font-mono text-5xl font-bold tabular-nums text-white leading-none pb-2",
											children: [matchScore, /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
												className: "text-2xl text-slate-500",
												children: "%"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 458,
												columnNumber: 36
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 457,
											columnNumber: 22
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "absolute bottom-0 left-0 h-1.5 bg-slate-800 w-full rounded-b-lg overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "h-full bg-emerald-500 transition-all duration-1000",
												style: { width: `${matchScore}%` }
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 461,
												columnNumber: 24
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 460,
											columnNumber: 22
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 456,
											columnNumber: 41
										}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "font-mono text-sm text-slate-600 py-3",
											children: "Pending Execution"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 465,
											columnNumber: 26
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 454,
										columnNumber: 16
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "rounded-lg border border-slate-700 bg-slate-950 p-5 flex-1 flex flex-col min-h-0 shadow-lg relative group",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "font-mono text-[10px] uppercase tracking-wider text-slate-400 flex justify-between items-center mb-3 shrink-0",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "Critical Gaps" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 472,
													columnNumber: 22
												}, this), gaps.length > 0 && /* @__PURE__ */ (void 0)("span", {
													className: "text-red-400 font-bold bg-red-950/50 px-1.5 py-0.5 rounded",
													children: gaps.length
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 473,
													columnNumber: 42
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 471,
												columnNumber: 20
											}, this), gaps.length > 0 && /* @__PURE__ */ (void 0)("button", {
												onClick: () => setViewingOutput("gaps"),
												className: "p-1 hover:bg-slate-800 rounded text-slate-500 hover:text-white transition-colors",
												title: "View full gaps report",
												children: /* @__PURE__ */ (void 0)(Maximize2, { className: "size-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 477,
													columnNumber: 24
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 476,
												columnNumber: 40
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 470,
											columnNumber: 18
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "flex-1 overflow-y-auto pr-2 custom-scrollbar",
											children: gaps.length === 0 ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "h-full flex items-center justify-center font-mono text-xs text-slate-600 text-center",
												children: agents.matcher.status === "done" ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
													className: "text-emerald-400 flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CircleCheck, { className: "size-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 483,
														columnNumber: 119
													}, this), " Alignment OK"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 483,
													columnNumber: 60
												}, this) : "Awaiting matcher block..."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 482,
												columnNumber: 41
											}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("ul", {
												className: "space-y-4",
												children: gaps.map((g, i) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("li", {
													className: "flex gap-3 leading-relaxed text-xs",
													children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CircleAlert, { className: "size-4 text-red-400 shrink-0 mt-0.5" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 486,
														columnNumber: 28
													}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
														className: "text-slate-300",
														children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Markdown, {
															components: {
																p: ({ node, ...props }) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { ...props }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 492,
																	columnNumber: 31
																}, this),
																strong: ({ node, ...props }) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("strong", {
																	className: "font-bold text-white",
																	...props
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 496,
																	columnNumber: 31
																}, this)
															},
															children: g
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 488,
															columnNumber: 30
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 487,
														columnNumber: 28
													}, this)]
												}, i, true, {
													fileName: _jsxFileName,
													lineNumber: 485,
													columnNumber: 44
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 484,
												columnNumber: 31
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 481,
											columnNumber: 18
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 469,
										columnNumber: 16
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 448,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 398,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "h-[35%] shrink-0 border-t border-slate-800 flex flex-col bg-[#050505] shadow-[inset_0_10px_20px_rgba(0,0,0,0.5)]",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "h-10 border-b border-slate-800 bg-slate-900 flex items-center px-6 shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "font-mono text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(SquareTerminal, { className: "size-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 512,
									columnNumber: 17
								}, this), " System Trace"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 511,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 510,
							columnNumber: 13
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex-1 p-5 font-mono text-xs overflow-y-auto custom-scrollbar",
							ref: traceScrollRef,
							children: trace.length === 0 && !running ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "h-full flex items-center justify-center text-slate-700",
								children: "SYSTEM READY. WAITING FOR EXECUTION."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 517,
								columnNumber: 49
							}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "space-y-2 pb-4",
								children: [trace.map((t) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TraceLine, { entry: t }, t.id, false, {
									fileName: _jsxFileName,
									lineNumber: 520,
									columnNumber: 35
								}, this)), AGENT_ORDER.filter((id) => agents[id].status === "running").map((id) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "mt-4 border-l-[3px] border-slate-800 pl-4 ml-1 py-1",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center gap-2 mb-2 opacity-80",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
											className: `font-bold ${AGENT_META[id].color}`,
											children: [
												"[",
												AGENT_META[id].label.toUpperCase(),
												"]"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 523,
											columnNumber: 27
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "size-2 rounded-full bg-emerald-500 animate-pulse" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 524,
											columnNumber: 27
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 522,
										columnNumber: 25
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "text-slate-400 whitespace-pre-wrap break-words leading-relaxed max-w-5xl",
										children: agents[id].output || "Establishing context..."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 526,
										columnNumber: 25
									}, this)]
								}, `stream-${id}`, true, {
									fileName: _jsxFileName,
									lineNumber: 521,
									columnNumber: 88
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 519,
								columnNumber: 26
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 516,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 509,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 395,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 334,
				columnNumber: 7
			}, this),
			viewingOutput && /* @__PURE__ */ (void 0)("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-8 animate-in fade-in duration-200",
				children: /* @__PURE__ */ (void 0)("div", {
					className: "bg-slate-950 w-full max-w-5xl h-full max-h-[85vh] rounded-xl border border-slate-800 shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-200",
					children: [/* @__PURE__ */ (void 0)("div", {
						className: "h-16 border-b border-slate-800 bg-slate-900 flex items-center justify-between px-6 shrink-0",
						children: [/* @__PURE__ */ (void 0)("div", {
							className: "flex items-center gap-3",
							children: viewingOutput === "gaps" ? /* @__PURE__ */ (void 0)(import_jsx_dev_runtime.Fragment, { children: [/* @__PURE__ */ (void 0)("div", {
								className: "p-2 rounded bg-slate-950 border border-red-500/50",
								children: /* @__PURE__ */ (void 0)(CircleAlert, { className: "size-5 text-red-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 545,
									columnNumber: 24
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 544,
								columnNumber: 22
							}, this), /* @__PURE__ */ (void 0)("div", { children: /* @__PURE__ */ (void 0)("h3", {
								className: "font-mono text-lg font-bold text-red-400",
								children: "Critical Gaps Report"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 548,
								columnNumber: 24
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 547,
								columnNumber: 22
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 543,
								columnNumber: 45
							}, this) : /* @__PURE__ */ (void 0)(import_jsx_dev_runtime.Fragment, { children: [/* @__PURE__ */ (void 0)("div", {
								className: `p-2 rounded bg-slate-950 border ${AGENT_META[viewingOutput].border}`,
								children: /* @__PURE__ */ (void 0)(FileText, { className: `size-5 ${AGENT_META[viewingOutput].color}` }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 554,
									columnNumber: 24
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 553,
								columnNumber: 22
							}, this), /* @__PURE__ */ (void 0)("div", { children: /* @__PURE__ */ (void 0)("h3", {
								className: `font-mono text-lg font-bold ${AGENT_META[viewingOutput].color}`,
								children: [AGENT_META[viewingOutput].label, " Report"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 557,
								columnNumber: 24
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 556,
								columnNumber: 22
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 552,
								columnNumber: 26
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 542,
							columnNumber: 15
						}, this), /* @__PURE__ */ (void 0)("button", {
							onClick: () => setViewingOutput(null),
							className: "p-2 rounded hover:bg-slate-800 text-slate-400 hover:text-white transition-colors",
							children: /* @__PURE__ */ (void 0)(X, { className: "size-6" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 564,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 563,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 541,
						columnNumber: 13
					}, this), /* @__PURE__ */ (void 0)("div", {
						className: "flex-1 overflow-y-auto p-10 custom-scrollbar",
						children: viewingOutput === "gaps" ? /* @__PURE__ */ (void 0)("div", {
							className: "max-w-4xl mx-auto space-y-6",
							children: gaps.map((g, i) => /* @__PURE__ */ (void 0)("div", {
								className: "flex gap-4 p-6 rounded-lg border border-slate-800 bg-slate-900/50 leading-relaxed text-sm",
								children: [/* @__PURE__ */ (void 0)(CircleAlert, { className: "size-5 text-red-400 shrink-0 mt-0.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 572,
									columnNumber: 24
								}, this), /* @__PURE__ */ (void 0)("div", {
									className: "text-slate-300",
									children: /* @__PURE__ */ (void 0)(Markdown, {
										components: {
											p: ({ node, ...props }) => /* @__PURE__ */ (void 0)("span", { ...props }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 578,
												columnNumber: 25
											}, this),
											strong: ({ node, ...props }) => /* @__PURE__ */ (void 0)("strong", {
												className: "font-bold text-white text-base block mb-2",
												...props
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 582,
												columnNumber: 25
											}, this)
										},
										children: g
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 574,
										columnNumber: 26
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 573,
									columnNumber: 24
								}, this)]
							}, i, true, {
								fileName: _jsxFileName,
								lineNumber: 571,
								columnNumber: 40
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 570,
							columnNumber: 43
						}, this) : agents[viewingOutput].output ? /* @__PURE__ */ (void 0)("div", {
							className: "prose-agent max-w-none text-sm leading-relaxed text-slate-300",
							children: /* @__PURE__ */ (void 0)(Markdown, {
								remarkPlugins: [remarkGfm],
								components: {
									h2: ({ node, ...props }) => /* @__PURE__ */ (void 0)("h2", {
										className: `mt-8 mb-4 text-base font-bold uppercase tracking-wider border-b border-slate-800 pb-2 ${AGENT_META[viewingOutput].color}`,
										...props
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 593,
										columnNumber: 21
									}, this),
									h3: ({ node, ...props }) => /* @__PURE__ */ (void 0)("h3", {
										className: "mt-8 mb-4 text-sm font-bold text-white uppercase tracking-wide",
										...props
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 597,
										columnNumber: 21
									}, this),
									p: ({ node, ...props }) => /* @__PURE__ */ (void 0)("p", {
										className: "mb-4 text-slate-300",
										...props
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 601,
										columnNumber: 21
									}, this),
									ul: ({ node, ...props }) => /* @__PURE__ */ (void 0)("ul", {
										className: "mb-4 ml-6 list-disc space-y-2 marker:text-slate-600",
										...props
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 605,
										columnNumber: 21
									}, this),
									ol: ({ node, ...props }) => /* @__PURE__ */ (void 0)("ol", {
										className: "mb-4 ml-6 list-decimal space-y-2 marker:text-slate-600",
										...props
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 609,
										columnNumber: 21
									}, this),
									strong: ({ node, ...props }) => /* @__PURE__ */ (void 0)("strong", {
										className: "font-bold text-white",
										...props
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 613,
										columnNumber: 21
									}, this),
									code: ({ node, ...props }) => /* @__PURE__ */ (void 0)("code", {
										className: "font-mono text-xs bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800 text-slate-300",
										...props
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 617,
										columnNumber: 21
									}, this)
								},
								children: viewingOutput === "supervisor" ? formatSupervisorOutput(agents[viewingOutput].output) : agents[viewingOutput].output
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 589,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 588,
							columnNumber: 69
						}, this) : /* @__PURE__ */ (void 0)("div", {
							className: "h-full flex flex-col items-center justify-center gap-4 text-slate-500 font-mono text-sm",
							children: agents[viewingOutput].status === "running" ? /* @__PURE__ */ (void 0)(import_jsx_dev_runtime.Fragment, { children: [/* @__PURE__ */ (void 0)("div", { className: "size-6 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 623,
								columnNumber: 78
							}, this), " Generating analysis..."] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 623,
								columnNumber: 76
							}, this) : "No output generated yet."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 622,
							columnNumber: 26
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 569,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 539,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 538,
				columnNumber: 25
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 307,
		columnNumber: 10
	}, this);
}
function GraphNode({ id, state, primary = false, onView }) {
	const meta = AGENT_META[id];
	const active = state.status === "running";
	const done = state.status === "done";
	const err = state.status === "error";
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: `w-full flex flex-col items-center relative group`,
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: [
				"relative flex flex-col items-center justify-center rounded-xl border-2 font-mono tracking-wider transition-all duration-300 w-full",
				primary ? "h-16" : "h-14",
				active ? `${meta.border} bg-slate-900 shadow-[0_0_20px_rgba(16,185,129,0.1)] scale-105` : done ? "border-slate-700 bg-slate-950 text-slate-200 hover:border-slate-500 shadow-lg" : err ? "border-red-900 bg-red-950/20 text-red-400" : "border-slate-800 bg-slate-950/50 text-slate-600"
			].join(" "),
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
					className: `text-xs font-bold uppercase ${active || done ? meta.color : "text-slate-600"}`,
					children: meta.label
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 650,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
					className: `text-[10px] mt-1 uppercase font-semibold ${active ? "opacity-100 text-slate-300" : "opacity-50"}`,
					children: state.status
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 653,
					columnNumber: 9
				}, this),
				active && /* @__PURE__ */ (void 0)("span", {
					className: "absolute -right-1.5 -top-1.5 flex size-3.5",
					children: [/* @__PURE__ */ (void 0)("span", { className: `animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 bg-current ${meta.color}` }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 659,
						columnNumber: 13
					}, this), /* @__PURE__ */ (void 0)("span", { className: `relative inline-flex rounded-full size-3.5 bg-current ${meta.color}` }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 660,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 658,
					columnNumber: 20
				}, this),
				done && /* @__PURE__ */ (void 0)("button", {
					onClick: onView,
					className: "absolute -bottom-3 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-800 border border-slate-600 text-slate-200 text-[10px] px-3 py-1 rounded-md flex items-center gap-1.5 hover:bg-slate-700 hover:text-white shadow-xl z-20",
					children: [/* @__PURE__ */ (void 0)(Maximize2, { className: "size-3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 665,
						columnNumber: 13
					}, this), " View"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 664,
					columnNumber: 18
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 649,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 648,
		columnNumber: 10
	}, this);
}
function TraceLine({ entry }) {
	const meta = AGENT_META[entry.agent];
	let color = "text-slate-400";
	if (entry.kind === "error") color = "text-red-400";
	else if (entry.kind === "tool") color = "text-slate-500 font-semibold";
	else if (entry.agent === "supervisor") color = "text-emerald-400";
	else if (entry.agent === "researcher") color = "text-blue-400";
	else if (entry.agent === "matcher") color = "text-purple-400";
	else if (entry.agent === "prep") color = "text-amber-400";
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "flex items-start gap-3 hover:bg-white/5 px-3 py-1.5 rounded transition-colors",
		children: [
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
				className: "shrink-0 font-mono text-[10px] text-slate-600 mt-[2px]",
				children: String(entry.id).padStart(4, "0")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 679,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
				className: `shrink-0 font-mono text-[11px] font-bold mt-[1px] w-12 ${color}`,
				children: meta.short
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 682,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
				className: "text-slate-400 break-words text-[11px] leading-relaxed",
				children: entry.text
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 685,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 678,
		columnNumber: 10
	}, this);
}
function extractSection(md, header) {
	if (!md) return [];
	const re = new RegExp(`\\*\\*${escapeRegex(header)}\\*\\*([\\s\\S]*?)(?=\\n\\*\\*|$)`, "i");
	const m = md.match(re);
	if (!m) return [];
	return extractBulletsFromChunk(m[1]);
}
function extractBulletsFromChunk(chunk) {
	return chunk.split("\n").map((l) => l.trim()).filter((l) => /^[-*•]\s+/.test(l) || /^\d+\.\s+/.test(l)).map((l) => l.replace(/^[-*•]\s+/, "").replace(/^\d+\.\s+/, "").trim()).filter(Boolean);
}
function escapeRegex(s) {
	return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
//#endregion
export { Index as component };
