import { o as __toESM } from "../_runtime.mjs";
import { n as AnimatePresence, t as motion } from "../_libs/framer-motion.mjs";
import { r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { t as require_jsx_dev_runtime } from "../_libs/react.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as useDropzone } from "../_libs/react-dropzone.mjs";
import { t as require_lib } from "../_libs/mammoth+[...].mjs";
import { n as getDocument, t as GlobalWorkerOptions } from "../_libs/pdfjs-dist.mjs";
import { d as CircleCheckBig, i as TriangleAlert, l as FileText, n as X, r as Upload, s as LoaderCircle } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ResumeUpload-D038Z0JC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_dev_runtime = require_jsx_dev_runtime();
var import_lib = /* @__PURE__ */ __toESM(require_lib());
var _jsxFileName$1 = "E:/2. Job Search [USA🗽]/5. ⭐Wynisco⭐/4. Onboarding/3. Technical Prep/z. Projects/Multi AI Agents with Langgraph/multi-agent-job-assistant/src/components/ui/sonner.tsx";
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	}, void 0, false, {
		fileName: _jsxFileName$1,
		lineNumber: 7,
		columnNumber: 5
	}, void 0);
};
var _jsxFileName = "E:/2. Job Search [USA🗽]/5. ⭐Wynisco⭐/4. Onboarding/3. Technical Prep/z. Projects/Multi AI Agents with Langgraph/multi-agent-job-assistant/src/components/ResumeUpload.tsx";
if (typeof window !== "undefined") GlobalWorkerOptions.workerSrc = "https://unpkg.com/pdfjs-dist@6.1.200/build/pdf.worker.min.mjs";
var DEMO_RESUME = `VINAY KUMAR
Senior Full-Stack Developer & AI Engineer
Email: vinay.kumar@example.com | LinkedIn: linkedin.com/in/vinaykumar | GitHub: github.com/vinaykumar

PROFESSIONAL SUMMARY
Experienced Senior Full-Stack Developer with 6+ years specializing in modern web technologies, AI/ML integration, and multi-agent system development. Proven expertise in building production-ready applications with React, TypeScript, Python, and cloud technologies. Currently developing advanced LangGraph-based multi-agent systems for intelligent job assistance platforms.

TECHNICAL SKILLS
• Frontend: React, TypeScript, Next.js, TanStack Router, Tailwind CSS, Framer Motion
• Backend: Node.js, Python, FastAPI, Express.js, REST APIs, GraphQL
• AI/ML: LangGraph, LangChain, OpenAI API, Multi-Agent Systems, Prompt Engineering
• Cloud: AWS, Cloudflare, Docker, Kubernetes, CI/CD Pipelines
• Databases: PostgreSQL, MongoDB, Redis, Vector Databases
• Tools: Git, Vite, Webpack, ESLint, Prettier, Jest, Playwright

EXPERIENCE

Senior Full-Stack Developer | Wynisco Technologies (2022 - Present)
• Architected and developed multi-agent AI systems using LangGraph for automated job application analysis
• Built production-ready React applications with advanced streaming interfaces and real-time updates
• Implemented sophisticated UI/UX with terminal-inspired designs, animations, and responsive layouts
• Integrated multiple AI providers (OpenAI, Gemini, OpenRouter) with intelligent fallback mechanisms
• Developed server-side rendering solutions using TanStack Start and Nitro for optimal performance

Full-Stack Developer | Tech Innovations Inc (2019 - 2022)
• Led development of enterprise SaaS applications serving 10,000+ users
• Built scalable REST APIs using Node.js and Python with 99.9% uptime
• Implemented advanced front-end architectures with React, TypeScript, and modern state management
• Optimized application performance resulting in 40% faster load times
• Mentored junior developers and established coding standards and best practices

Junior Developer | StartupXYZ (2018 - 2019)
• Developed responsive web applications using React and modern JavaScript
• Collaborated with design teams to implement pixel-perfect UI components
• Integrated third-party APIs and payment processing systems
• Participated in agile development cycles and code reviews

PROJECTS

Multi-Agent Job Assistant Platform (2024)
• Built sophisticated supervisor-coordinated multi-agent system using LangGraph patterns
• Implemented real-time streaming architecture with Server-Sent Events
• Created terminal-inspired UI with advanced animations and state visualization
• Integrated resume parsing, job description analysis, and intelligent matching algorithms
• Technologies: React, TypeScript, TanStack Start, Tailwind CSS, LangGraph, AI APIs

E-Commerce Platform (2023)
• Developed full-stack e-commerce solution handling $1M+ in transactions
• Built scalable microservices architecture with Docker and Kubernetes
• Implemented advanced search, filtering, and recommendation systems
• Technologies: Next.js, Node.js, PostgreSQL, Redis, AWS

Real-Time Collaboration Tool (2022)
• Created real-time collaborative workspace with live editing capabilities
• Implemented WebSocket-based communication and conflict resolution
• Built responsive interface supporting 100+ concurrent users
• Technologies: React, Socket.io, Express.js, MongoDB

EDUCATION
Bachelor of Technology in Computer Science
Indian Institute of Technology (IIT) | 2014-2018
• Relevant Coursework: Data Structures, Algorithms, Machine Learning, Database Systems

CERTIFICATIONS
• AWS Certified Developer Associate (2023)
• Google Cloud Professional Developer (2022)
• Advanced React Patterns Certification (2023)

ACHIEVEMENTS
• Built and deployed 15+ production applications with 99.9% uptime
• Contributed to open-source projects with 500+ GitHub stars
• Speaker at React and AI conferences (2023-2024)
• Led team of 5 developers in successful project deliveries`;
var SAMPLE_RESUMES = {
	"AI Engineer": `ALEX CHEN
AI Engineer & Machine Learning Specialist
Email: alex.chen@email.com | LinkedIn: /in/alexchen

EXPERIENCE
• 5+ years in AI/ML development with Python, TensorFlow, PyTorch
• Built production ML pipelines processing 1M+ data points daily
• Expertise in LLMs, multi-agent systems, and prompt engineering
• PhD in Computer Science with focus on Natural Language Processing`,
	"Frontend Developer": `SARAH JOHNSON
Senior Frontend Developer
Email: sarah.j@email.com | GitHub: /sarahj

EXPERIENCE
• 7+ years React, TypeScript, and modern frontend frameworks
• Expert in responsive design, accessibility, and performance optimization
• Built component libraries used by 50+ developers
• Strong UX/UI design background with Figma proficiency`,
	"Backend Developer": `MIKE RODRIGUEZ
Backend Engineer & Cloud Architect
Email: mike.r@email.com | LinkedIn: /in/mikerodriguez

EXPERIENCE
• 8+ years building scalable backend systems
• Expertise in Node.js, Python, Go, and microservices architecture
• AWS/GCP certified with extensive DevOps experience
• Led teams building systems handling millions of requests`
};
var ResumeUpload = ({ onResumeChange, resume, disabled = false }) => {
	const [uploadStatus, setUploadStatus] = (0, import_react.useState)("idle");
	const [errorMessage, setErrorMessage] = (0, import_react.useState)("");
	const [fileName, setFileName] = (0, import_react.useState)("");
	const [inputMethod, setInputMethod] = (0, import_react.useState)("upload");
	const extractTextFromPdf = async (file) => {
		try {
			console.log("Starting PDF extraction for:", file.name, "Size:", file.size);
			const arrayBuffer = await file.arrayBuffer();
			console.log("ArrayBuffer loaded, size:", arrayBuffer.byteLength);
			const loadingTask = getDocument({
				data: arrayBuffer,
				useSystemFonts: true,
				disableFontFace: false,
				standardFontDataUrl: "https://unpkg.com/pdfjs-dist@6.1.200/standard_fonts/",
				stopAtErrors: false,
				isEvalSupported: false,
				useWorkerFetch: false
			});
			console.log("PDF loading task created");
			const pdf = await loadingTask.promise;
			console.log("PDF loaded successfully. Pages:", pdf.numPages);
			let fullText = "";
			for (let i = 1; i <= Math.min(pdf.numPages, 10); i++) try {
				const pageText = (await (await pdf.getPage(i)).getTextContent()).items.filter((item) => "str" in item && item.str?.trim()).map((item) => item.str.trim()).join(" ").replace(/\s+/g, " ");
				if (pageText) fullText += pageText + "\n\n";
				console.log(`Page ${i} extracted: ${pageText.length} chars`);
			} catch (pageError) {
				console.warn(`Error on page ${i}:`, pageError);
			}
			if (!fullText.trim()) throw new Error("No text extracted from PDF. The PDF might be image-based or protected.");
			console.log("Total text extracted:", fullText.length, "chars");
			return fullText.trim();
		} catch (error) {
			console.error("PDF Error Details:", error);
			if (error instanceof Error) if (error.message.includes("Invalid PDF")) throw new Error("Invalid PDF file. Please try a different PDF or convert to DOCX/TXT.");
			else if (error.message.includes("password")) throw new Error("PDF is password protected. Please unlock it first or use DOCX/TXT.");
			else if (error.message.includes("Worker")) throw new Error("PDF processing error. Please try converting to DOCX or TXT format.");
			else throw new Error(`PDF Error: ${error.message}. Try DOCX or TXT format.`);
			throw new Error("Failed to read PDF. Try converting to DOCX or TXT format.");
		}
	};
	const extractTextFromDocx = async (file) => {
		const arrayBuffer = await file.arrayBuffer();
		return (await import_lib.extractRawText({ arrayBuffer })).value;
	};
	const extractTextFromTxt = async (file) => {
		return await file.text();
	};
	const processFile = async (file) => {
		setUploadStatus("processing");
		setErrorMessage("");
		setFileName(file.name);
		try {
			let extractedText = "";
			const fileType = file.type.toLowerCase();
			const fileName = file.name.toLowerCase();
			if (fileType === "application/pdf" || fileName.endsWith(".pdf")) extractedText = await extractTextFromPdf(file);
			else if (fileType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || fileName.endsWith(".docx")) extractedText = await extractTextFromDocx(file);
			else if (fileType === "text/plain" || fileName.endsWith(".txt")) extractedText = await extractTextFromTxt(file);
			else throw new Error("Unsupported file type. Please upload PDF, DOCX, or TXT files.");
			if (!extractedText.trim()) throw new Error("No text could be extracted from the file.");
			onResumeChange(extractedText.trim());
			setUploadStatus("success");
		} catch (error) {
			setUploadStatus("error");
			setErrorMessage(error instanceof Error ? error.message : "Failed to process file");
		}
	};
	const { getRootProps, getInputProps, isDragActive } = useDropzone({
		onDrop: (0, import_react.useCallback)((acceptedFiles, rejectedFiles) => {
			if (disabled) return;
			if (rejectedFiles.length > 0) {
				setUploadStatus("error");
				setErrorMessage("File too large or invalid format. Max 10MB, PDF/DOCX/TXT only.");
				return;
			}
			if (acceptedFiles.length > 0) processFile(acceptedFiles[0]);
		}, [disabled]),
		accept: {
			"application/pdf": [".pdf"],
			"application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
			"text/plain": [".txt"]
		},
		maxFiles: 1,
		maxSize: 10 * 1024 * 1024,
		disabled
	});
	const clearResume = () => {
		onResumeChange("");
		setUploadStatus("idle");
		setFileName("");
		setErrorMessage("");
	};
	const loadSampleResume = (key) => {
		if (key === "demo") onResumeChange(DEMO_RESUME);
		else onResumeChange(SAMPLE_RESUMES[key]);
		setUploadStatus("success");
		setFileName(`${key} Sample Resume.txt`);
	};
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
					type: "button",
					onClick: () => setInputMethod("upload"),
					className: `flex-1 rounded border px-3 py-2 font-mono text-xs font-bold uppercase tracking-wider transition-colors ${inputMethod === "upload" ? "border-accent bg-accent/10 text-accent" : "border-border bg-background text-muted-foreground hover:text-foreground"}`,
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Upload, { className: "mr-2 inline size-3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 320,
						columnNumber: 11
					}, void 0), "Upload File"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 311,
					columnNumber: 9
				}, void 0), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
					type: "button",
					onClick: () => setInputMethod("text"),
					className: `flex-1 rounded border px-3 py-2 font-mono text-xs font-bold uppercase tracking-wider transition-colors ${inputMethod === "text" ? "border-accent bg-accent/10 text-accent" : "border-border bg-background text-muted-foreground hover:text-foreground"}`,
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(FileText, { className: "mr-2 inline size-3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 332,
						columnNumber: 11
					}, void 0), "Paste Text"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 323,
					columnNumber: 9
				}, void 0)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 310,
				columnNumber: 7
			}, void 0),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(AnimatePresence, {
				mode: "wait",
				children: inputMethod === "upload" ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(motion.div, {
					initial: {
						opacity: 0,
						y: 10
					},
					animate: {
						opacity: 1,
						y: 0
					},
					exit: {
						opacity: 0,
						y: -10
					},
					transition: { duration: .2 },
					children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						...getRootProps(),
						className: `relative overflow-hidden rounded-lg border-2 border-dashed p-8 text-center transition-all duration-300 resume-dropzone ${isDragActive ? "animate-upload-pulse border-accent bg-accent/5 shadow-lg shadow-accent/20" : uploadStatus === "success" ? "border-accent/40 bg-accent/5" : uploadStatus === "error" ? "border-destructive/40 bg-destructive/5" : "border-border bg-background hover:border-accent/40 hover:bg-accent/5"} ${disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", { ...getInputProps() }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 359,
								columnNumber: 15
							}, void 0),
							uploadStatus === "processing" && /* @__PURE__ */ (void 0)("div", {
								className: "absolute inset-0 overflow-hidden",
								children: /* @__PURE__ */ (void 0)("div", { className: "absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-accent to-transparent animate-processing-scan" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 364,
									columnNumber: 19
								}, void 0)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 363,
								columnNumber: 17
							}, void 0),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "relative z-10 space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "mx-auto flex size-16 items-center justify-center rounded-full border border-border bg-background",
										children: uploadStatus === "processing" ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(LoaderCircle, { className: "size-6 animate-spin text-accent" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 371,
											columnNumber: 21
										}, void 0) : uploadStatus === "success" ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CircleCheckBig, { className: "size-6 text-accent" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 373,
											columnNumber: 21
										}, void 0) : uploadStatus === "error" ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TriangleAlert, { className: "size-6 text-destructive" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 375,
											columnNumber: 21
										}, void 0) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Upload, { className: "size-6 text-muted-foreground" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 377,
											columnNumber: 21
										}, void 0)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 369,
										columnNumber: 17
									}, void 0),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: uploadStatus === "processing" ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "font-mono text-sm font-bold text-accent",
											children: "PROCESSING FILE..."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 384,
											columnNumber: 23
										}, void 0), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "font-mono text-xs text-muted-foreground",
											children: "extracting → parsing → analyzing"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 385,
											columnNumber: 23
										}, void 0)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 383,
										columnNumber: 21
									}, void 0) : uploadStatus === "success" ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "font-mono text-sm font-bold text-accent",
											children: "RESUME LOADED ✓"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 391,
											columnNumber: 23
										}, void 0), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "font-mono text-xs text-muted-foreground",
											children: [
												fileName,
												" • ",
												resume.length.toLocaleString(),
												" chars"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 392,
											columnNumber: 23
										}, void 0)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 390,
										columnNumber: 21
									}, void 0) : uploadStatus === "error" ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "font-mono text-sm font-bold text-destructive",
											children: "PROCESSING FAILED"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 398,
											columnNumber: 23
										}, void 0), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-xs text-destructive",
											children: errorMessage
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 401,
											columnNumber: 23
										}, void 0)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 397,
										columnNumber: 21
									}, void 0) : isDragActive ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "font-mono text-sm font-bold text-accent",
											children: "DROP FILE TO ANALYZE"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 405,
											columnNumber: 23
										}, void 0), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "font-mono text-xs text-muted-foreground",
											children: "PDF, DOCX, TXT supported"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 408,
											columnNumber: 23
										}, void 0)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 404,
										columnNumber: 21
									}, void 0) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
												className: "font-semibold text-foreground",
												children: "Drop your resume here"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 414,
												columnNumber: 23
											}, void 0),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
												className: "text-sm text-muted-foreground",
												children: "or click to browse files"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 415,
												columnNumber: 23
											}, void 0),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
												className: "font-mono text-xs text-muted-foreground",
												children: "PDF, DOCX, TXT • Max 10MB"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 416,
												columnNumber: 23
											}, void 0)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 413,
										columnNumber: 21
									}, void 0) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 381,
										columnNumber: 17
									}, void 0),
									(uploadStatus === "success" || uploadStatus === "error") && /* @__PURE__ */ (void 0)("button", {
										type: "button",
										onClick: (e) => {
											e.stopPropagation();
											clearResume();
										},
										className: "inline-flex items-center gap-2 rounded border border-muted px-3 py-1 font-mono text-xs text-muted-foreground transition-colors hover:border-foreground hover:text-foreground",
										children: [/* @__PURE__ */ (void 0)(X, { className: "size-3" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 432,
											columnNumber: 21
										}, void 0), "Clear"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 424,
										columnNumber: 19
									}, void 0)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 368,
								columnNumber: 15
							}, void 0)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 347,
						columnNumber: 13
					}, void 0)
				}, "upload", false, {
					fileName: _jsxFileName,
					lineNumber: 339,
					columnNumber: 11
				}, void 0) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(motion.div, {
					initial: {
						opacity: 0,
						y: 10
					},
					animate: {
						opacity: 1,
						y: 0
					},
					exit: {
						opacity: 0,
						y: -10
					},
					transition: { duration: .2 },
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("textarea", {
						value: resume,
						onChange: (e) => onResumeChange(e.target.value),
						placeholder: "Paste your resume text here...",
						disabled,
						className: "h-40 w-full resize-none rounded border border-border bg-background p-4 font-mono text-sm leading-relaxed text-foreground placeholder:text-muted-foreground/40 focus:border-accent focus:outline-none focus:ring-0",
						spellCheck: false
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 448,
						columnNumber: 13
					}, void 0), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
							className: "font-mono text-xs text-muted-foreground",
							children: [resume.length.toLocaleString(), " characters"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 457,
							columnNumber: 15
						}, void 0), resume && /* @__PURE__ */ (void 0)("button", {
							type: "button",
							onClick: clearResume,
							className: "inline-flex items-center gap-1 rounded border border-muted px-2 py-1 font-mono text-xs text-muted-foreground transition-colors hover:border-foreground hover:text-foreground",
							children: [/* @__PURE__ */ (void 0)(X, { className: "size-3" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 466,
								columnNumber: 19
							}, void 0), "Clear"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 461,
							columnNumber: 17
						}, void 0)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 456,
						columnNumber: 13
					}, void 0)]
				}, "text", true, {
					fileName: _jsxFileName,
					lineNumber: 440,
					columnNumber: 11
				}, void 0)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 337,
				columnNumber: 7
			}, void 0),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "h-px flex-1 bg-border" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 478,
							columnNumber: 11
						}, void 0),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "font-mono text-xs uppercase tracking-wider text-muted-foreground",
							children: "Sample Resumes"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 479,
							columnNumber: 11
						}, void 0),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "h-px flex-1 bg-border" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 482,
							columnNumber: 11
						}, void 0)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 477,
					columnNumber: 9
				}, void 0), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "button",
						onClick: () => loadSampleResume("demo"),
						className: "group rounded border border-accent/30 bg-accent/5 px-3 py-2 text-center transition-all hover:border-accent/50 hover:bg-accent/10",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "font-mono text-xs font-bold text-accent",
							children: "DEMO"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 490,
							columnNumber: 13
						}, void 0), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "text-xs text-muted-foreground",
							children: "Full-Stack + AI"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 491,
							columnNumber: 13
						}, void 0)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 485,
						columnNumber: 11
					}, void 0), Object.keys(SAMPLE_RESUMES).map((key) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "button",
						onClick: () => loadSampleResume(key),
						className: "group rounded border border-border bg-background px-3 py-2 text-center transition-all hover:border-accent/40 hover:bg-accent/5",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "font-mono text-xs font-bold text-foreground",
							children: key.split(" ")[0]
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 500,
							columnNumber: 15
						}, void 0), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "text-xs text-muted-foreground",
							children: key
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 501,
							columnNumber: 15
						}, void 0)]
					}, key, true, {
						fileName: _jsxFileName,
						lineNumber: 494,
						columnNumber: 13
					}, void 0))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 484,
					columnNumber: 9
				}, void 0)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 476,
				columnNumber: 7
			}, void 0)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 308,
		columnNumber: 5
	}, void 0);
};
//#endregion
export { Toaster$1 as n, ResumeUpload as t };
