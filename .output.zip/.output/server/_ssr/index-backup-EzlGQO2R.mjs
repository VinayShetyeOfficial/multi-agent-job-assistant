import { o as __toESM } from "../_runtime.mjs";
import { r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { t as require_jsx_dev_runtime } from "../_libs/react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Toaster$1, t as ResumeUpload } from "./ResumeUpload-D038Z0JC.mjs";
import { t as Markdown } from "../_libs/react-markdown+[...].mjs";
import { t as remarkGfm } from "../_libs/remark-gfm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/index-backup-EzlGQO2R.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_dev_runtime = require_jsx_dev_runtime();
var _jsxFileName = "E:/2. Job Search [USA🗽]/5. ⭐Wynisco⭐/4. Onboarding/3. Technical Prep/z. Projects/Multi AI Agents with Langgraph/multi-agent-job-assistant/src/routes/index-backup.tsx?tsr-split=component";
var AGENT_META = {
	supervisor: {
		label: "Supervisor",
		short: "SUP",
		color: "text-accent",
		description: "Routes tasks across the agent graph"
	},
	researcher: {
		label: "Researcher",
		short: "RES",
		color: "text-[color:var(--agent-researcher)]",
		description: "Company & market intelligence",
		tool: "web_search"
	},
	matcher: {
		label: "Matcher",
		short: "MAT",
		color: "text-[color:var(--agent-matcher)]",
		description: "Resume ↔ JD gap analysis",
		tool: "read_resume"
	},
	prep: {
		label: "Prep Agent",
		short: "PREP",
		color: "text-[color:var(--agent-prep)]",
		description: "Interview prep synthesis"
	}
};
var AGENT_ORDER = [
	"supervisor",
	"researcher",
	"matcher",
	"prep"
];
var SAMPLE_JD = `Role: Senior Backend Engineer — Distributed Systems
Company: Northstar Labs (Series C, real-time infra)

We're looking for an engineer to own the core event pipeline that
powers our low-latency trading analytics platform. You'll design
gRPC services in Rust, deploy Kubernetes operators, and work
closely with the ML platform team on feature-store latency.

Requirements:
- 5+ years backend experience, ideally in Rust or Go
- Deep understanding of distributed systems (consensus, sharding)
- Experience running Kubernetes at scale, ideally with custom operators
- Comfortable with observability: Prometheus, OpenTelemetry
- Bonus: prior exposure to feature stores or ML infra`;
function Index() {
	const [jd, setJd] = (0, import_react.useState)(SAMPLE_JD);
	const [resume, setResume] = (0, import_react.useState)("");
	const [running, setRunning] = (0, import_react.useState)(false);
	const [trace, setTrace] = (0, import_react.useState)([]);
	const [agents, setAgents] = (0, import_react.useState)({
		supervisor: {
			status: "idle",
			output: ""
		},
		researcher: {
			status: "idle",
			output: ""
		},
		matcher: {
			status: "idle",
			output: ""
		},
		prep: {
			status: "idle",
			output: ""
		}
	});
	const [startTs, setStartTs] = (0, import_react.useState)(null);
	const [elapsed, setElapsed] = (0, import_react.useState)(0);
	const traceScrollRef = (0, import_react.useRef)(null);
	const abortRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!running || startTs == null) return;
		const id = setInterval(() => setElapsed(Date.now() - startTs), 100);
		return () => clearInterval(id);
	}, [running, startTs]);
	(0, import_react.useEffect)(() => {
		const el = traceScrollRef.current;
		if (el) el.scrollTop = el.scrollHeight;
	}, [trace]);
	const matchScore = (0, import_react.useMemo)(() => {
		const m = agents.matcher.output.match(/(\d{2,3})\s*%/);
		if (!m) return null;
		const n = parseInt(m[1], 10);
		if (isNaN(n)) return null;
		return Math.min(100, Math.max(0, n));
	}, [agents.matcher.output]);
	const gaps = (0, import_react.useMemo)(() => extractSection(agents.matcher.output, "Gaps"), [agents.matcher.output]);
	const suggestedQuestion = (0, import_react.useMemo)(() => {
		return extractBullets(agents.prep.output, "Likely Technical Questions")[0] ?? null;
	}, [agents.prep.output]);
	const reset = (0, import_react.useCallback)(() => {
		setTrace([]);
		setAgents({
			supervisor: {
				status: "idle",
				output: ""
			},
			researcher: {
				status: "idle",
				output: ""
			},
			matcher: {
				status: "idle",
				output: ""
			},
			prep: {
				status: "idle",
				output: ""
			}
		});
		setElapsed(0);
		setStartTs(null);
	}, []);
	const start = (0, import_react.useCallback)(async () => {
		if (running) return;
		if (jd.trim().length < 20) {
			toast.error("Paste a longer job description to run the graph.");
			return;
		}
		if (resume.trim().length < 50) {
			toast.error("Please upload or paste your resume to get personalized analysis.");
			return;
		}
		reset();
		setRunning(true);
		setStartTs(Date.now());
		const controller = new AbortController();
		abortRef.current = controller;
		let idCounter = 0;
		const pushTrace = (t) => setTrace((prev) => [...prev, {
			...t,
			id: `t${idCounter++}`
		}]);
		try {
			const res = await fetch("/api/analyze", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					jd,
					resume
				}),
				signal: controller.signal
			});
			if (!res.ok || !res.body) {
				const msg = await res.text().catch(() => "");
				throw new Error(msg || `Request failed (${res.status})`);
			}
			const reader = res.body.getReader();
			const decoder = new TextDecoder();
			let buf = "";
			while (true) {
				const { value, done } = await reader.read();
				if (done) break;
				buf += decoder.decode(value, { stream: true });
				const chunks = buf.split("\n\n");
				buf = chunks.pop() ?? "";
				for (const chunk of chunks) {
					const line = chunk.trim();
					if (!line.startsWith("data:")) continue;
					const raw = line.slice(5).trim();
					if (!raw) continue;
					let evt;
					try {
						evt = JSON.parse(raw);
					} catch {
						continue;
					}
					if (evt.type === "agent_start") {
						const id = evt.agent;
						setAgents((a) => ({
							...a,
							[id]: {
								...a[id],
								status: "running",
								output: "",
								startedAt: Date.now()
							}
						}));
						pushTrace({
							agent: id,
							kind: "info",
							text: `[${AGENT_META[id].label.toUpperCase()}] node activated`
						});
						const tool = AGENT_META[id].tool;
						if (tool) pushTrace({
							agent: id,
							kind: "tool",
							text: `tool.invoke(${tool}) → streaming`
						});
					} else if (evt.type === "token") {
						const id = evt.agent;
						const delta = String(evt.delta ?? "");
						setAgents((a) => ({
							...a,
							[id]: {
								...a[id],
								output: a[id].output + delta
							}
						}));
					} else if (evt.type === "agent_done") {
						const id = evt.agent;
						setAgents((a) => ({
							...a,
							[id]: {
								...a[id],
								status: "done",
								output: evt.content ?? a[id].output,
								finishedAt: Date.now()
							}
						}));
						pushTrace({
							agent: id,
							kind: "result",
							text: `[${AGENT_META[id].label.toUpperCase()}] finished (${(evt.content ?? "").length} chars)`
						});
					} else if (evt.type === "error") {
						const id = evt.agent ?? "supervisor";
						setAgents((a) => ({
							...a,
							[id]: {
								...a[id],
								status: "error"
							}
						}));
						pushTrace({
							agent: id,
							kind: "error",
							text: `ERROR: ${evt.message}`
						});
						toast.error(evt.message ?? "Agent error");
					} else if (evt.type === "done") pushTrace({
						agent: "supervisor",
						kind: "info",
						text: `[SUPERVISOR] graph complete → case file compiled`
					});
				}
			}
		} catch (err) {
			if (err.name === "AbortError") return;
			const msg = err instanceof Error ? err.message : String(err);
			toast.error(msg);
			pushTrace({
				agent: "supervisor",
				kind: "error",
				text: `FATAL: ${msg}`
			});
		} finally {
			setRunning(false);
			abortRef.current = null;
		}
	}, [
		jd,
		resume,
		reset,
		running
	]);
	const stop = (0, import_react.useCallback)(() => {
		abortRef.current?.abort();
		setRunning(false);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "min-h-screen bg-background text-foreground font-sans",
		children: [
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Toaster$1, {
				theme: "dark",
				richColors: true,
				position: "top-right"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 295,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("nav", {
				className: "sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "mx-auto flex h-14 max-w-[1600px] items-center justify-between px-6",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-8",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "grid size-6 place-items-center rounded-sm bg-accent",
								children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "size-2 rounded-[1px] bg-background" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 303,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 302,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "font-mono text-sm font-bold tracking-tighter text-accent",
								children: [
									"AGENTIC.OS ",
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "text-muted-foreground",
										children: "//"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 306,
										columnNumber: 28
									}, this),
									" RECRUIT"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 305,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 301,
							columnNumber: 13
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "hidden gap-6 font-mono text-[11px] uppercase tracking-widest text-muted-foreground md:flex",
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("a", {
									href: "#console",
									className: "transition-colors hover:text-foreground",
									children: "Console"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 310,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("a", {
									href: "#architecture",
									className: "transition-colors hover:text-foreground",
									children: "Architecture"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 313,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("a", {
									href: "https://github.com/langchain-ai/langgraph",
									target: "_blank",
									rel: "noreferrer",
									className: "transition-colors hover:text-foreground",
									children: "LangGraph"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 316,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 309,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 300,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-3",
						children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "hidden items-center gap-2 rounded-full border border-border bg-card px-3 py-1 sm:flex",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: `size-1.5 rounded-full ${running ? "bg-accent animate-pulse" : "bg-muted-foreground"}` }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "font-mono text-[10px] uppercase text-muted-foreground",
								children: running ? "Graph executing" : "System ready"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 324,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 322,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 321,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 299,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 298,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("main", {
				className: "mx-auto max-w-[1600px] space-y-6 p-4 md:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("section", {
						id: "console",
						className: "grid grid-cols-1 gap-6 lg:grid-cols-12",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "space-y-5 lg:col-span-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/5 px-3 py-1",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "size-1.5 rounded-full bg-accent" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 337,
										columnNumber: 15
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "font-mono text-[10px] uppercase tracking-widest text-accent",
										children: "v2.0 · Resume + JD Analysis"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 338,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 336,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h1", {
									className: "text-balance text-4xl font-bold leading-[1.05] tracking-tight md:text-5xl",
									children: [
										"Orchestrate your",
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("br", {}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 344,
											columnNumber: 15
										}, this),
										"next",
										" ",
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
											className: "text-accent [text-shadow:0_0_30px_color-mix(in_oklab,var(--accent)_50%,transparent)]",
											children: "hire."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 346,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 342,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "max-w-[38ch] text-sm leading-relaxed text-muted-foreground",
									children: "Upload your resume and paste a job description. Watch a supervisor route specialized agents to analyze your fit, gather company intel, and generate interview prep — all streaming in real time."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 350,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "space-y-2 border-l-2 border-border pl-4",
									children: AGENT_ORDER.map((id) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
											className: `font-mono text-[10px] font-bold ${AGENT_META[id].color}`,
											children: AGENT_META[id].short
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 357,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
											className: "text-xs text-muted-foreground",
											children: AGENT_META[id].description
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 360,
											columnNumber: 19
										}, this)]
									}, id, true, {
										fileName: _jsxFileName,
										lineNumber: 356,
										columnNumber: 38
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 355,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 335,
							columnNumber: 11
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "space-y-6 lg:col-span-8",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "rounded-xl border border-border bg-card p-1 shadow-2xl shadow-black/40",
								children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "rounded-lg bg-background p-5",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "mb-4 flex items-center justify-between border-b border-border pb-3",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "flex gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "rounded bg-[color:var(--agent-matcher)] px-2.5 py-1 font-mono text-[10px] text-background",
												children: "RESUME.pdf"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 373,
												columnNumber: 21
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "hidden rounded border border-border px-2.5 py-1 font-mono text-[10px] text-muted-foreground sm:block",
												children: "personalized analysis"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 376,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 372,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "flex items-center gap-2 font-mono text-[10px] text-muted-foreground",
											children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [resume.length.toLocaleString(), " chars"] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 381,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 380,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 371,
										columnNumber: 17
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ResumeUpload, {
										onResumeChange: setResume,
										resume,
										disabled: running
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 384,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 370,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 369,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "rounded-xl border border-border bg-card p-1 shadow-2xl shadow-black/40",
								children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "rounded-lg bg-background p-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "mb-3 flex items-center justify-between border-b border-border pb-3",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "flex gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
													className: "rounded bg-secondary px-2.5 py-1 font-mono text-[10px] text-foreground",
													children: "JOB_DESCRIPTION.txt"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 393,
													columnNumber: 21
												}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
													className: "hidden rounded border border-border px-2.5 py-1 font-mono text-[10px] text-muted-foreground sm:block",
													children: "utf-8 · plain"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 396,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 392,
												columnNumber: 19
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "flex items-center gap-2 font-mono text-[10px] text-muted-foreground",
												children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [jd.length.toLocaleString(), " chars"] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 401,
													columnNumber: 21
												}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
													type: "button",
													onClick: () => setJd(SAMPLE_JD),
													className: "rounded border border-border px-2 py-0.5 uppercase tracking-wider transition-colors hover:border-accent/50 hover:text-accent",
													children: "Load sample"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 402,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 400,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 391,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("textarea", {
											value: jd,
											onChange: (e) => setJd(e.target.value),
											spellCheck: false,
											placeholder: "Paste the Job Description here...",
											className: "h-40 w-full resize-none border-none bg-transparent font-mono text-sm leading-relaxed text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-0"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 407,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "mt-2 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-3",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "flex items-center gap-3 font-mono text-[10px] text-muted-foreground",
												children: [
													/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
														className: "flex items-center gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "size-1.5 rounded-full bg-accent" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 411,
															columnNumber: 23
														}, this), "MODEL: gemini-2.5-flash"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 410,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
														className: "hidden sm:inline",
														children: "·"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 414,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
														className: "hidden sm:inline",
														children: "STREAM: sse"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 415,
														columnNumber: 21
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 409,
												columnNumber: 19
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "flex gap-2",
												children: [running && /* @__PURE__ */ (void 0)("button", {
													onClick: stop,
													className: "rounded border border-destructive/40 bg-destructive/10 px-4 py-2 font-mono text-xs font-bold uppercase tracking-wider text-destructive transition-colors hover:bg-destructive/20",
													children: "Abort"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 418,
													columnNumber: 33
												}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
													onClick: start,
													disabled: running || !resume.trim() || !jd.trim(),
													className: "group flex items-center gap-2 rounded bg-accent px-6 py-2.5 font-mono text-xs font-bold uppercase tracking-wider text-accent-foreground shadow-lg shadow-accent/20 transition-all hover:bg-accent/90 disabled:cursor-not-allowed disabled:opacity-50",
													children: [running ? "Executing..." : "Start Analysis", /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
														className: "transition-transform group-hover:translate-x-0.5",
														children: "→"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 423,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 421,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 417,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 408,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 390,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 389,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 367,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 334,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("section", {
						className: "grid grid-cols-1 gap-6 lg:grid-cols-12 lg:h-[720px]",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "flex flex-col rounded-xl border border-border bg-card p-5 lg:col-span-3",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "mb-6 flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "font-mono text-[10px] uppercase tracking-widest text-muted-foreground",
										children: "Graph Topology"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 437,
										columnNumber: 15
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "font-mono text-[10px] text-accent",
										children: running ? "LIVE" : "IDLE"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 440,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 13
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "relative flex flex-1 flex-col items-center justify-center gap-8",
									children: [
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(GraphNode, {
											id: "supervisor",
											state: agents.supervisor,
											width: "w-32",
											primary: true
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 444,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "relative w-full flex justify-center",
											children: [
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-0 left-1/2 -translate-x-1/2 h-6 w-px bg-border" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 449,
													columnNumber: 17
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-6 left-[16.66%] right-[16.66%] h-px bg-border" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 452,
													columnNumber: 17
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-6 left-[16.66%] h-6 w-px bg-border" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 455,
													columnNumber: 17
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-6 left-1/2 -translate-x-1/2 h-6 w-px bg-border" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 458,
													columnNumber: 17
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-6 right-[16.66%] h-6 w-px bg-border" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 461,
													columnNumber: 17
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 447,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "grid w-full grid-cols-3 gap-2",
											children: [
												"researcher",
												"matcher",
												"prep"
											].map((id) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(GraphNode, {
												id,
												state: agents[id]
											}, id, false, {
												fileName: _jsxFileName,
												lineNumber: 465,
												columnNumber: 77
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 464,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "mt-auto w-full space-y-2 border-t border-border pt-4",
											children: [
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ToolRow, {
													name: "web_search",
													active: agents.researcher.status === "running"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 469,
													columnNumber: 17
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ToolRow, {
													name: "read_resume",
													active: agents.matcher.status === "running"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 470,
													columnNumber: 17
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ToolRow, {
													name: "synthesize",
													active: agents.prep.status === "running"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 471,
													columnNumber: 17
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 468,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 443,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 435,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "scanline flex flex-col overflow-hidden rounded-xl border border-border bg-card lg:col-span-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center justify-between border-b border-border bg-background/50 px-4 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
												className: "font-mono text-[10px] uppercase tracking-widest text-muted-foreground",
												children: "Execution Trace"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 480,
												columnNumber: 17
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
												className: "font-mono text-[9px] text-muted-foreground/60",
												children: "/var/log/agents.stream"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 483,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 479,
											columnNumber: 15
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
											className: "font-mono text-[10px] text-accent",
											children: [(elapsed / 1e3).toFixed(1), "s ELAPSED"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 487,
											columnNumber: 15
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 478,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										ref: traceScrollRef,
										className: "grid-bg flex-1 space-y-2 overflow-y-auto p-5 font-mono text-xs leading-relaxed min-h-[380px]",
										children: [
											trace.length === 0 && !running && /* @__PURE__ */ (void 0)("div", {
												className: "flex h-full min-h-[300px] flex-col items-center justify-center gap-3 text-center text-muted-foreground",
												children: [/* @__PURE__ */ (void 0)("div", {
													className: "font-mono text-[10px] uppercase tracking-[0.25em]",
													children: "Awaiting instruction"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 494,
													columnNumber: 19
												}, this), /* @__PURE__ */ (void 0)("p", {
													className: "max-w-xs text-xs",
													children: "The trace will stream here once the supervisor dispatches the first agent."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 497,
													columnNumber: 19
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 493,
												columnNumber: 50
											}, this),
											trace.map((t) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TraceLine, { entry: t }, t.id, false, {
												fileName: _jsxFileName,
												lineNumber: 502,
												columnNumber: 31
											}, this)),
											AGENT_ORDER.filter((id) => agents[id].status === "running").map((id) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "animate-stream rounded border border-border/60 bg-background/60 p-3",
												children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
													className: "mb-2 flex items-center gap-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
															className: `font-mono text-[10px] font-bold ${AGENT_META[id].color}`,
															children: [
																"[",
																AGENT_META[id].label.toUpperCase(),
																"]"
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 506,
															columnNumber: 21
														}, this),
														/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
															className: "font-mono text-[9px] text-muted-foreground",
															children: "streaming…"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 509,
															columnNumber: 21
														}, this),
														/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "ml-auto inline-block size-1.5 animate-pulse rounded-full bg-accent" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 510,
															columnNumber: 21
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 505,
													columnNumber: 19
												}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
													className: "whitespace-pre-wrap break-words text-[11px] text-foreground/90",
													children: agents[id].output || /* @__PURE__ */ (void 0)("span", {
														className: "text-muted-foreground",
														children: ["thinking", /* @__PURE__ */ (void 0)("span", {
															className: "animate-blink",
															children: "▍"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 515,
															columnNumber: 25
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 513,
														columnNumber: 43
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 512,
													columnNumber: 19
												}, this)]
											}, `stream-${id}`, true, {
												fileName: _jsxFileName,
												lineNumber: 504,
												columnNumber: 84
											}, this)),
											running && AGENT_ORDER.every((id) => agents[id].status !== "running") && /* @__PURE__ */ (void 0)("div", {
												className: "flex items-center gap-2 text-accent",
												children: [/* @__PURE__ */ (void 0)("div", { className: "size-1.5 animate-pulse rounded-full bg-accent" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 521,
													columnNumber: 19
												}, this), /* @__PURE__ */ (void 0)("span", { children: "routing next node..." }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 522,
													columnNumber: 19
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 520,
												columnNumber: 87
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 492,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "scanline-bar" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 525,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 477,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "space-y-4 lg:col-span-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "rounded-xl border border-border bg-card p-5",
										children: [
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "mb-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground",
												children: "Match Score"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 531,
												columnNumber: 15
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "flex items-baseline gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
													className: "font-mono text-5xl font-bold tabular-nums",
													children: [matchScore ?? "--", /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
														className: "text-xl text-muted-foreground",
														children: "%"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 537,
														columnNumber: 19
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 535,
													columnNumber: 17
												}, this), agents.matcher.status === "running" && /* @__PURE__ */ (void 0)("span", {
													className: "font-mono text-[10px] text-accent animate-pulse",
													children: "computing…"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 539,
													columnNumber: 57
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 534,
												columnNumber: 15
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "mt-3 h-1 w-full overflow-hidden bg-border",
												children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
													className: "h-full bg-accent transition-all duration-500",
													style: { width: `${matchScore ?? 0}%` }
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 544,
													columnNumber: 17
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 543,
												columnNumber: 15
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 530,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "rounded-xl border border-border bg-card p-5",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "mb-3 font-mono text-[10px] uppercase tracking-widest text-muted-foreground",
											children: "Key Gaps"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 551,
											columnNumber: 15
										}, this), gaps.length === 0 ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "font-mono text-[11px] text-muted-foreground/60",
											children: agents.matcher.status === "done" ? "No blocking gaps identified." : "Awaiting matcher output…"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 554,
											columnNumber: 36
										}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("ul", {
											className: "space-y-3",
											children: gaps.slice(0, 4).map((g, i) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("li", {
												className: "flex items-start gap-3 text-sm leading-7",
												children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
													className: "mt-1 shrink-0 font-mono text-destructive",
													children: "[!]"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 558,
													columnNumber: 23
												}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
													className: "min-w-0 text-muted-foreground/95",
													children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Markdown, {
														remarkPlugins: [remarkGfm],
														components: {
															p: ({ node, ...props }) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { ...props }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 564,
																columnNumber: 27
															}, this),
															strong: ({ node, ...props }) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("strong", {
																className: "font-semibold text-foreground",
																...props
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 568,
																columnNumber: 27
															}, this)
														},
														children: g
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 560,
														columnNumber: 25
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 559,
													columnNumber: 23
												}, this)]
											}, i, true, {
												fileName: _jsxFileName,
												lineNumber: 557,
												columnNumber: 51
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 556,
											columnNumber: 24
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 550,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "rounded-xl bg-accent p-5 text-accent-foreground shadow-lg shadow-accent/20",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "mb-3 font-mono text-[10px] font-bold uppercase tracking-widest",
											children: "Suggested Prep Question"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 578,
											columnNumber: 15
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-sm font-medium leading-relaxed",
											children: suggestedQuestion ? `"${suggestedQuestion}"` : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
												className: "opacity-70",
												children: "Prep agent will generate a tailored question here."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 582,
												columnNumber: 65
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 581,
											columnNumber: 15
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 577,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 529,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 433,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("section", {
						className: "grid grid-cols-1 gap-6 lg:grid-cols-2",
						children: [
							"researcher",
							"matcher",
							"prep"
						].map((id) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ArtifactCard, {
							id,
							state: agents[id],
							className: id === "prep" ? "lg:col-span-2" : void 0
						}, id, false, {
							fileName: _jsxFileName,
							lineNumber: 592,
							columnNumber: 71
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 591,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("section", {
						id: "architecture",
						className: "rounded-xl border border-border bg-card p-8 md:p-12",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mb-10 text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground",
										children: "Architecture Overview"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 598,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
										className: "mt-3 text-2xl font-bold md:text-3xl",
										children: "Built on LangGraph cycles"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 601,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
										className: "mx-auto mt-3 max-w-xl text-sm text-muted-foreground",
										children: "A stateful supervisor routes tasks across specialized agents, each with their own tool set. State is shared, handoffs are explicit, and every step is streamed to the trace."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 602,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 597,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ArchitectureDiagram, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 608,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mt-10 grid grid-cols-1 gap-6 md:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ArchitecturePillar, {
										title: "Cycles > Chains",
										body: "Agents can loop back, refine findings, and self-correct on output quality — not just run once."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 611,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ArchitecturePillar, {
										title: "Shared State",
										body: "A typed state object flows between nodes so context persists without token bloat."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 612,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ArchitecturePillar, {
										title: "Human-in-the-loop",
										body: "Built-in breakpoints let a recruiter approve findings before the matcher escalates."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 613,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 610,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 596,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 332,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("footer", {
				className: "border-t border-border",
				children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "mx-auto flex max-w-[1600px] flex-col items-center justify-between gap-3 px-6 py-6 font-mono text-[10px] text-muted-foreground md:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "AGENTIC.OS v1.0.4 // KERNEL STABLE" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 620,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "flex gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "MODEL: GEMINI-2.5-FLASH" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 622,
							columnNumber: 13
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "UPTIME: 99.99%" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 623,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 621,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 619,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 618,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 294,
		columnNumber: 10
	}, this);
}
function GraphNode({ id, state, width = "w-full", primary = false }) {
	const meta = AGENT_META[id];
	const active = state.status === "running";
	const done = state.status === "done";
	const err = state.status === "error";
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: `${width} flex flex-col items-center`,
		children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: [
				"relative flex items-center justify-center rounded border font-mono text-[10px] font-bold tracking-wider transition-colors",
				primary ? "h-11" : "h-9",
				"w-full px-2",
				active ? "animate-node-active border-accent bg-accent/10 text-accent" : done ? "border-accent/40 bg-accent/5 text-accent" : err ? "border-destructive/50 bg-destructive/10 text-destructive" : "border-border bg-background text-muted-foreground"
			].join(" "),
			children: [meta.short, active && /* @__PURE__ */ (void 0)("span", { className: "absolute -right-1 -top-1 size-2 rounded-full bg-accent" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 650,
				columnNumber: 20
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 648,
			columnNumber: 7
		}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "mt-1.5 font-mono text-[9px] uppercase tracking-wider text-muted-foreground/70",
			children: state.status
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 652,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 647,
		columnNumber: 10
	}, this);
}
function ToolRow({ name, active }) {
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "flex items-center justify-between font-mono text-[9px]",
		children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
			className: "text-muted-foreground",
			children: ["TOOL: ", name.toUpperCase()]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 665,
			columnNumber: 7
		}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
			className: active ? "text-accent animate-pulse" : "text-muted-foreground/60",
			children: active ? "RUNNING" : "IDLE"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 666,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 664,
		columnNumber: 10
	}, this);
}
function TraceLine({ entry }) {
	const meta = AGENT_META[entry.agent];
	const color = entry.kind === "error" ? "text-destructive" : entry.kind === "tool" ? "text-[color:var(--agent-researcher)]" : meta.color;
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "animate-stream flex gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
				className: "shrink-0 font-mono text-[10px] text-muted-foreground/50",
				children: String(entry.id).padStart(3, "0")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 679,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
				className: `shrink-0 font-mono text-[10px] font-bold ${color}`,
				children: [
					"[",
					meta.label.toUpperCase(),
					"]"
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 682,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
				className: "text-foreground/90",
				children: entry.text
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 685,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 678,
		columnNumber: 10
	}, this);
}
function ArtifactCard({ id, state, className }) {
	const meta = AGENT_META[id];
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: `rounded-xl border border-border bg-card p-6 ${className ?? ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "mb-4 flex items-center justify-between border-b border-border pb-3",
			children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
					className: `font-mono text-[10px] font-bold ${meta.color}`,
					children: meta.short
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 701,
					columnNumber: 11
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h3", {
					className: "font-semibold text-foreground",
					children: [meta.label, " Report"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 702,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 700,
				columnNumber: 9
			}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
				className: ["rounded border px-2 py-0.5 font-mono text-[9px] uppercase tracking-wider", state.status === "done" ? "border-accent/40 text-accent" : state.status === "running" ? "border-accent/40 text-accent animate-pulse" : state.status === "error" ? "border-destructive/40 text-destructive" : "border-border text-muted-foreground"].join(" "),
				children: state.status
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 704,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 699,
			columnNumber: 7
		}, this), state.output ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "prose-agent break-words text-sm leading-7 text-foreground/90",
			children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Markdown, {
				remarkPlugins: [remarkGfm],
				components: {
					h2: ({ node, ...props }) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
						className: "mt-6 mb-3 text-base font-semibold uppercase tracking-[0.2em] text-accent/90",
						...props
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 713,
						columnNumber: 15
					}, this),
					h3: ({ node, ...props }) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h3", {
						className: "mt-5 mb-2 text-sm font-semibold tracking-[0.08em] text-foreground",
						...props
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 717,
						columnNumber: 15
					}, this),
					p: ({ node, ...props }) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
						className: "mb-4 text-[0.95rem] leading-7 text-muted-foreground/90",
						...props
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 721,
						columnNumber: 15
					}, this),
					ul: ({ node, ...props }) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("ul", {
						className: "mb-4 ml-5 list-disc space-y-2 text-[0.95rem] leading-7 text-muted-foreground/90",
						...props
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 725,
						columnNumber: 15
					}, this),
					li: ({ node, ...props }) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("li", {
						className: "text-[0.95rem] leading-7 text-muted-foreground/90",
						...props
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 729,
						columnNumber: 15
					}, this),
					strong: ({ node, ...props }) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("strong", {
						className: "font-semibold text-foreground",
						...props
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 733,
						columnNumber: 15
					}, this)
				},
				children: state.output
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 709,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 708,
			columnNumber: 23
		}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
			className: "font-mono text-xs text-muted-foreground/60",
			children: state.status === "running" ? "Streaming output…" : "No output yet. Run the graph."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 737,
			columnNumber: 18
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 698,
		columnNumber: 10
	}, this);
}
function ArchitecturePillar({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "border-l-2 border-accent/40 pl-4",
		children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "mb-2 font-mono text-[10px] uppercase tracking-widest text-accent",
			children: title
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 750,
			columnNumber: 7
		}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
			className: "text-sm leading-relaxed text-muted-foreground",
			children: body
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 753,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 749,
		columnNumber: 10
	}, this);
}
function ArchitectureDiagram() {
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "mx-auto grid max-w-3xl grid-cols-1 gap-6",
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "rounded-lg border border-border bg-background p-6",
			children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "flex flex-col items-center gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "rounded border border-border px-3 py-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground",
						children: "JOB_DESCRIPTION"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 761,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "h-6 w-px bg-border" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 764,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "rounded border border-accent/50 bg-accent/10 px-4 py-2 font-mono text-[10px] font-bold uppercase tracking-wider text-accent",
						children: "▸ SUPERVISOR NODE"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 767,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "relative w-full max-w-lg",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "mx-auto h-6 w-px bg-border" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 773,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "mx-auto h-px w-full bg-border" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 774,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "grid grid-cols-3",
								children: [
									"researcher",
									"matcher",
									"prep"
								].map((id) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "flex flex-col items-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "h-6 w-px bg-border" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 777,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: `rounded border border-border bg-background px-3 py-1.5 font-mono text-[10px] font-bold uppercase tracking-wider ${AGENT_META[id].color}`,
											children: AGENT_META[id].label
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 778,
											columnNumber: 19
										}, this),
										AGENT_META[id].tool && /* @__PURE__ */ (void 0)(import_jsx_dev_runtime.Fragment, { children: [/* @__PURE__ */ (void 0)("div", { className: "my-1 h-4 w-px bg-border/60" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 782,
											columnNumber: 23
										}, this), /* @__PURE__ */ (void 0)("div", {
											className: "rounded border border-border/60 bg-background px-2 py-0.5 font-mono text-[9px] text-muted-foreground",
											children: [AGENT_META[id].tool, "()"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 783,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 781,
											columnNumber: 43
										}, this)
									]
								}, id, true, {
									fileName: _jsxFileName,
									lineNumber: 776,
									columnNumber: 75
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 775,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 772,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "mt-4 h-px w-32 bg-border" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 791,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "rounded border border-accent/30 bg-accent/5 px-4 py-2 font-mono text-[10px] uppercase tracking-wider text-accent",
						children: "CASE_FILE.pdf"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 792,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 759,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 758,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 757,
		columnNumber: 10
	}, this);
}
function extractSection(md, header) {
	if (!md) return [];
	const re = new RegExp(`\\*\\*${escapeRegex(header)}\\*\\*([\\s\\S]*?)(?=\\n\\*\\*|$)`, "i");
	const m = md.match(re);
	if (!m) return [];
	return extractBulletsFromChunk(m[1]);
}
function extractBullets(md, header) {
	return extractSection(md, header);
}
function extractBulletsFromChunk(chunk) {
	return chunk.split("\n").map((l) => l.trim()).filter((l) => /^[-*•]\s+/.test(l) || /^\d+\.\s+/.test(l)).map((l) => l.replace(/^[-*•]\s+/, "").replace(/^\d+\.\s+/, "").trim()).filter(Boolean);
}
function escapeRegex(s) {
	return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
//#endregion
export { Index as component };
