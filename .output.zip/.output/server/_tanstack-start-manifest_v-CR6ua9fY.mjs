//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CR6ua9fY.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "E:/2. Job Search [USA🗽]/5. ⭐Wynisco⭐/4. Onboarding/3. Technical Prep/z. Projects/Multi AI Agents with Langgraph/multi-agent-job-assistant/src/routes/__root.tsx",
		children: [
			"/",
			"/index-backup",
			"/index_temp",
			"/api/analyze"
		],
		preloads: ["/assets/index-9n5YxKTN.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-9n5YxKTN.js"
		} }]
	},
	"/": {
		filePath: "E:/2. Job Search [USA🗽]/5. ⭐Wynisco⭐/4. Onboarding/3. Technical Prep/z. Projects/Multi AI Agents with Langgraph/multi-agent-job-assistant/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CIbzuwlH.js",
			"/assets/ResumeUpload-DBt6BREf.js",
			"/assets/zap-CETXILgq.js"
		]
	},
	"/index-backup": {
		filePath: "E:/2. Job Search [USA🗽]/5. ⭐Wynisco⭐/4. Onboarding/3. Technical Prep/z. Projects/Multi AI Agents with Langgraph/multi-agent-job-assistant/src/routes/index-backup.tsx",
		children: void 0,
		preloads: ["/assets/index-backup-Cx-6Ged1.js", "/assets/ResumeUpload-DBt6BREf.js"]
	},
	"/index_temp": {
		filePath: "E:/2. Job Search [USA🗽]/5. ⭐Wynisco⭐/4. Onboarding/3. Technical Prep/z. Projects/Multi AI Agents with Langgraph/multi-agent-job-assistant/src/routes/index_temp.tsx",
		children: void 0,
		preloads: [
			"/assets/index_temp-CGSN3bT8.js",
			"/assets/ResumeUpload-DBt6BREf.js",
			"/assets/zap-CETXILgq.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
